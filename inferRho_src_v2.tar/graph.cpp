/*
	Copyright, Ying Wang, yingw09@gmail.com
*/

#include "graph.h"

Node::Node(int id, double ct, double rt, int na):
 ID(id), coalTime(ct), recTime(rt), numAlleles(na)
{
	leftD=NULL; rightD=NULL; leftA=NULL; rightA=NULL; bkpoint=-1; follow=-1;
	leftAncLocs = NULL; rightAncLocs = NULL;
	leftStart=-1; leftEnd=-1; //the first and the last plus 1 elements that are not 999.
	rightStart=-1; rightEnd=-1;
}

Node::Node(Node& x)
{
	ID = x.ID;
	coalTime = x.coalTime;
	recTime = x.recTime;

	bkpoint = x.bkpoint;
	follow = x.follow;
	numAlleles = x.numAlleles;

	if(x.leftAncLocs!=NULL)
	{
		leftAncLocs = new ALLELE[numAlleles];
		for(int i=0; i<numAlleles; i++) leftAncLocs[i]=x.leftAncLocs[i];
	}
	else leftAncLocs=NULL;

	if(x.rightAncLocs!=NULL)
	{
		rightAncLocs = new ALLELE[numAlleles];
		for(int i=0; i<numAlleles; i++)
		{
			rightAncLocs[i]=x.rightAncLocs[i];
			assert(rightAncLocs[i]=='A'||rightAncLocs[i]=='T'||rightAncLocs[i]=='C'||
			rightAncLocs[i]=='G'||rightAncLocs[i]==999);
		}
	}
	else rightAncLocs=NULL;

	leftStart = x.leftStart;
	leftEnd = x.leftEnd;
	rightStart = x.rightStart;
	rightEnd = x.rightEnd;

	leftD=NULL; rightD=NULL; leftA=NULL; rightA=NULL;
}

Node::~Node()
{
	if(this!=NULL)
	{
		leftD=NULL; rightD=NULL; leftA=NULL; rightA=NULL;
		delete [] leftAncLocs; delete [] rightAncLocs;
		leftAncLocs=NULL; rightAncLocs=NULL;
	}
}

bool Node::isTip()
{
	if(coalTime==0 && recTime==0) return true;
	else return false;
}

void Node::setLeftAncLocs(ALLELE* x)
{
	if(leftAncLocs!=NULL) delete [] leftAncLocs;
	leftAncLocs = NULL;

	leftAncLocs = x;
	assert(leftAncLocs!=NULL);

	for(int i=0; i<numAlleles; i++){ if(leftAncLocs[i]!=999) {leftStart=i;break;}}
	for(int i=numAlleles-1; i>=0; i--) {if(leftAncLocs[i]!=999) {leftEnd=i+1; break;}}
}

void Node::setRightAncLocs(ALLELE* x)
{
	if(rightAncLocs!=NULL) delete [] rightAncLocs;
	rightAncLocs = NULL;

	rightAncLocs = x;
	assert(rightAncLocs!=NULL);

	for(int i=0; i<numAlleles; i++){ if(rightAncLocs[i]!=999) {rightStart=i;break;}}
	for(int i=numAlleles-1; i>=0; i--) {if(rightAncLocs[i]!=999) {rightEnd=i+1; break;}}
}

void Node::printAncLocs(ofstream& ofs)
{
	if(leftAncLocs!=NULL)
	{
		for(int i=0; i<numAlleles; i++) ofs<<leftAncLocs[i]<<"\t";
	}
	else {for(int i=0; i<numAlleles; i++) ofs<<999<<"\t";}

	if(rightAncLocs!=NULL)
	{
		for(int i=0; i<numAlleles; i++) ofs<<rightAncLocs[i]<<"\t";
	}
	else {for(int i=0; i<numAlleles; i++) ofs<<999<<"\t";}
	ofs<<endl;
}

void Node::printAncLocs()
{
	cout<<"[ ";
	if(leftAncLocs!=NULL)
	{
		for(int i=0; i<numAlleles; i++)
		{
			if(leftAncLocs[i] == 999) cout<<"na ";
			else cout<<(char)leftAncLocs[i]<<" ";
		}
	}
	else {for(int i=0; i<numAlleles; i++) cout<<"- ";}
	cout<<" ]"<<leftStart<<","<<leftEnd<<" ";

	cout<<"[ ";
	if(rightAncLocs!=NULL)
	{
		for(int i=0; i<numAlleles; i++)
		{
			if(rightAncLocs[i] == 999) cout<<"na ";
			else cout<<(char)rightAncLocs[i]<<" ";
		}
	}
	else {for(int i=0; i<numAlleles; i++) cout<<"- ";}
	cout<<" ]"<<rightStart<<","<<rightEnd<<endl;
}

void Node::verifyAncLocs()
{
	int index1=-1, index2=-1;
	if(leftAncLocs!=NULL)
	{
		for(int i=0; i<numAlleles; i++){ if(leftAncLocs[i]!=999) {index1=i;break;}}
		for(int i=numAlleles-1; i>=0; i--) {if(leftAncLocs[i]!=999) {index2=i+1; break;}}
	}
	assert(index1==leftStart);
	assert(index2==leftEnd);

	index1=-1, index2=-1;
	if(rightAncLocs!=NULL)
	{
		for(int i=0; i<numAlleles; i++){ if(rightAncLocs[i]!=999) {index1=i;break;}}
		for(int i=numAlleles-1; i>=0; i--) {if(rightAncLocs[i]!=999) {index2=i+1; break;}}
	}
	assert(index1==rightStart);
	assert(index2==rightEnd);
}

void Node::breakAncLocs(const ALLELE* locs, int* positions)
{
	delete [] leftAncLocs;
	delete [] rightAncLocs;
	leftAncLocs = NULL; rightAncLocs = NULL;

	ALLELE* vec1; ALLELE* vec2;
	vec1 = new ALLELE[numAlleles];
	vec2 = new ALLELE[numAlleles];

	for(int i=0; i<numAlleles; i++)
	{
		if(positions[i]>bkpoint)
		{
			vec1[i] = 999;
			vec2[i] = locs[i];
		}
		else
		{
			vec1[i] = locs[i];
			vec2[i] = 999;
		}
	}

	if(follow==LEFT_LEFT) { leftAncLocs = vec1; rightAncLocs = vec2;}
	else {rightAncLocs = vec1; leftAncLocs = vec2;}

	leftStart=-1; leftEnd=-1; rightStart=-1; rightEnd=-1;
	for(int i=0; i<numAlleles; i++) {if(leftAncLocs[i]!=999) {leftStart=i; break;}}
	for(int i=numAlleles-1; i>=0; i--) {if(leftAncLocs[i]!=999) {leftEnd=i+1; break;}}
	for(int i=0; i<numAlleles; i++) {if(rightAncLocs[i]!=999) {rightStart=i; break;}}
	for(int i=numAlleles-1; i>=0; i--) {if(rightAncLocs[i]!=999) {rightEnd=i+1; break;}}

	verifyAncLocs();
}


void Node::unionAncLocs(ALLELE* locs1, ALLELE* locs2, gsl_rng* gslr)
{
	if(rightAncLocs!=NULL)
	{
		delete [] rightAncLocs;
		rightAncLocs = NULL;
		rightStart=-1; rightEnd=-1;
	}

	ALLELE* leftanclocs = new ALLELE[numAlleles];
	for(int i=0; i<numAlleles; i++) leftanclocs[i] = locs1[i];
	for(int i=0; i<numAlleles; i++)
	{
		if(leftanclocs[i]==999 && locs2[i]!=999)
			leftanclocs[i]=locs2[i];
	}

	setLeftAncLocs(leftanclocs);

	verifyAncLocs();
}


double Node::updateAncLocs(bool changeBkpoint, bool changeFollow, int* positions, gsl_rng* gslr)
{
	double propRatio = 1;
	if(isRec())
	{
		Node* dec = getDec();
		ALLELE* vec;
		int stAnc; int enAnc;

		if(!dec->isRec() || (dec->isRec() && dec->leftA->ID==ID))
		{
			vec=dec->leftAncLocs; stAnc=dec->leftStart; enAnc=dec->leftEnd;
		}
		else { vec=dec->rightAncLocs; stAnc=dec->rightStart; enAnc=dec->rightEnd; }
		if(enAnc-stAnc<=1) return 0;

		stAnc = positions[stAnc];
		enAnc = positions[enAnc-1];

		double lowb, highb;
		if(follow==LEFT_LEFT) { highb = positions[rightEnd-1]; lowb = positions[leftStart]; }
		else { highb = positions[leftEnd-1]; lowb = positions[rightStart];}

		if(changeBkpoint || (stAnc!=lowb || enAnc!=highb))
		{
			bkpoint = gsl_rng_uniform_pos(gslr)*(enAnc-stAnc)+stAnc;
			propRatio *= (enAnc-stAnc)/(highb-lowb);
			assert(enAnc-stAnc>0);
		}

		if(changeFollow)
		{
			if(gsl_rng_uniform_pos(gslr)<0.5) follow=LEFT_LEFT; else follow=LEFT_RIGHT;
		}

		breakAncLocs(vec, positions);
	}
	else
	{
		Node* dec1 = leftD; Node* dec2 = rightD;

		ALLELE* vec1; ALLELE* vec2;
		if(dec1->getID()==dec2->getID())
		{
			vec1 = dec1->leftAncLocs; vec2 = dec1->rightAncLocs;
		}
		else
		{
			if(!dec1->isRec() || (dec1->isRec()&& dec1->leftA->ID==ID)) vec1 = dec1->leftAncLocs;
			else vec1 = dec1->rightAncLocs;

			if(!dec2->isRec() || (dec2->isRec()&& dec2->leftA->ID==ID)) vec2 = dec2->leftAncLocs;
			else vec2 = dec2->rightAncLocs;
		}

		assert(vec1!=NULL&& vec2!=NULL);
		unionAncLocs(vec1, vec2, gslr);
	}

	verifyAncLocs();

	return propRatio;
}


//------------------------End of functions for Node-------------------------------
//-------------------------------------------------------------------------------

Graph::Graph(int numtips, int numloci):
numTips(numtips), numLoci(numloci)
{
	Root=NULL; numRecs=0; numInternNodes=0; TotalTime=0;
}

Graph::Graph(Graph& X)
{
	copyGraph(*this, X);
}


void Graph::copyGraph(Graph& newg, Graph& oldg)
{
	if(newg.NodesVector.size()!=0) newg.destroy();

	newg.numTips = oldg.numTips;
	newg.numLoci = oldg.numLoci;
	newg.TotalTime = oldg.TotalTime;
	newg.numInternNodes = oldg.numInternNodes;
	newg.numRecs = oldg.numRecs;

	sort(oldg.NodesVector.begin(), oldg.NodesVector.end(), Util::compareTwoNodesID);

	vector<Node*>::iterator vi;
	for(vi=oldg.NodesVector.begin(); vi!=oldg.NodesVector.end(); vi++)
	{
		Node* anode;
		anode = new Node(*(*vi));

		newg.NodesVector.push_back(anode);
	}

	for(int i=0; i<numTips+numInternNodes; i++)
	{
		if(oldg.NodesVector[i]->getleftA()!=NULL)
			newg.NodesVector[i]->setleftA(newg.NodesVector[oldg.NodesVector[i]->getleftA()->getID()]);
		if(oldg.NodesVector[i]->getrightA()!=NULL)
			newg.NodesVector[i]->setrightA(newg.NodesVector[oldg.NodesVector[i]->getrightA()->getID()]);
		if(oldg.NodesVector[i]->getleftD()!=NULL)
			newg.NodesVector[i]->setleftD(newg.NodesVector[oldg.NodesVector[i]->getleftD()->getID()]);
		if(oldg.NodesVector[i]->getrightD()!=NULL)
			newg.NodesVector[i]->setrightD(newg.NodesVector[oldg.NodesVector[i]->getrightD()->getID()]);
	}
	newg.Root = newg.NodesVector[oldg.Root->getID()];

	sort(newg.NodesVector.begin(), newg.NodesVector.end(), Util::compareTwoNodesT);
	sort(oldg.NodesVector.begin(), oldg.NodesVector.end(), Util::compareTwoNodesT);

	newg.logllh = oldg.logllh;
	newg.logprior = oldg.logprior;
}


Graph::~Graph()
{
	destroy();
}

Graph& Graph::operator=(Graph& X)
{
	destroy();
	copyGraph(*this, X);
	return *this;
}

void Graph::destroy()
{
	vector<Node*>::iterator it;

	for(it=NodesVector.begin(); it!=NodesVector.end(); it++) delete (*it);
	NodesVector.clear();
}


void Graph::resetGraph(vector<Node*>& nodesvector)
{
	destroy();

	sort(nodesvector.begin(), nodesvector.end(), Util::compareTwoNodesID);

	vector<Node*>::iterator vi;
	for(vi=nodesvector.begin(); vi!=nodesvector.end(); vi++)
	{
		Node* anode;
		anode = new Node(*(*vi));

		NodesVector.push_back(anode);
	}
	numInternNodes = (int)nodesvector.size()-numTips;

	numRecs=0;

	for(int i=0; i<numTips+numInternNodes; i++)
	{
		for(int j=0; j<4; j++)
		{
			if(nodesvector[i]->ids[j]!=-1)
			{
				int id = nodesvector[i]->ids[j];
				for(vi=NodesVector.begin(); vi!=NodesVector.end(); vi++)
				{
					if((*vi)->getID()==id)
					{
						if(j==0) NodesVector[i]->setleftD(*vi);
						else if(j==1) NodesVector[i]->setrightD(*vi);
						else if(j==2) NodesVector[i]->setleftA(*vi);
						else NodesVector[i]->setrightA(*vi);
						break;
					}
				}
			}
		}
		if(NodesVector[i]->isRec()) numRecs++;
	}

	for(vi=NodesVector.begin()+numTips; vi!=NodesVector.end()-1; vi++)
	{
		if((*vi)->getTime() == (*(vi+1))->getTime())
		{
			double t = (*(vi+1))->getTime();
			double nt = t+1e-8;
			if((*(vi+1))->isRec()) (*(vi+1))->setrecTime(nt);
			else (*(vi+1))->setcoalTime(nt);
		}
	}

	sort(NodesVector.begin(), NodesVector.end(), Util::compareTwoNodesT);

	Root = (*(NodesVector.end()-1));
}

double Graph::getTMRCA()
{
	return Root->getcoalTime();
}

void Graph::traverse(vector<Node*>& remember, Node* entry)
{
	if(!remember.empty()){remember.clear();}
	Node* cursor=entry;
	Node* tmp;
	vector<Node*> S;
	S.push_back(cursor);

	while(!S.empty())
	{
		cursor=S.back();
		remember.push_back(cursor);
		S.pop_back();

		if(cursor->getleftA()!=NULL && !containsNode(S, (cursor->getleftA()->getID())) && !containsNode(remember,(cursor->getleftA()->getID())))
		{S.push_back(cursor->getleftA()); }
		if(cursor->getrightA()!=NULL && !containsNode(S, cursor->getrightA()->getID()) && !containsNode(remember,cursor->getrightA()->getID()))
		{S.push_back(cursor->getrightA());}
		if(cursor->getrightD()!=NULL && !containsNode(S,cursor->getrightD()->getID()) && !containsNode(remember,cursor->getrightD()->getID()))
		{
			tmp=cursor;
			S.push_back(cursor->getrightD());
			cursor=cursor->getrightD();
			while(cursor->getleftD()!=NULL && !containsNode(S, (cursor->getleftD()->getID())) && !containsNode(remember,(cursor->getleftD()->getID())))
			{
				cursor=cursor->getleftD();
				S.push_back(cursor);
			}
			cursor=tmp;
		}
		if(cursor->getleftD()!=NULL && !containsNode(S,cursor->getleftD()->getID()) && !containsNode(remember, cursor->getleftD()->getID()))
		{S.push_back(cursor->getleftD());}
	}
}

bool Graph::containsNode(vector<Node*>& x, int id)
{
	vector<Node*>::iterator vi;
	for (vi=x.begin(); vi!=x.end(); vi++)
	{
		if(((*vi)->getID())==id) return true;
	}
	return false;
}

void Graph::createTipNodes(int** seqmatrix)
{
	int i;
	for(i=0; i<numTips; i++)
	{
		Node* anode;
		anode = new Node(i, 0, 0, numLoci);

		ALLELE* leftanc = new ALLELE[numLoci];
		for(int j=0; j<numLoci; j++) leftanc[j] = seqmatrix[i][j];

		anode->setLeftAncLocs(leftanc);
		NodesVector.push_back(anode);
	}
}

void Graph::simuBNTree(int** seqmatrix, gsl_rng* gslr)
{
	createTipNodes(seqmatrix);

	TotalTime=0;
	int nlins = numTips;
	double wtime=0; double tc=-1;
	vector<int> availNodes;
	for(int i=0; i<numTips; i++) availNodes.push_back(i);
	int id = numTips;

	while( nlins >1 )
	{
		double wtimePreG = wtime;
		tc = -2*log(1-gsl_rng_uniform_pos(gslr))/(nlins*(nlins-1)); tc += wtime;

		wtime=tc;

		TotalTime += nlins*(wtime - wtimePreG);

		int index; Node* newnode; Node* found; int size;

		newnode= new Node(id, wtime, 0, numLoci);

		for(int i=0;i<2; i++)
		{
			size = int(availNodes.size());
			assert(size>0);
			index = gsl_rng_uniform_int(gslr, size);
			found = NodesVector[availNodes[index]];
			found->setleftA(newnode);
			availNodes.erase(availNodes.begin()+index);
			if(i==0) newnode->setleftD(found);
			else newnode->setrightD(found);
		}

		ALLELE* cur = new ALLELE[numLoci];
		ALLELE* ancs = newnode->getleftD()->getAncLocs(LEFT);
		for(int i=0; i<numLoci; i++) {cur[i]=ancs[i];}
		newnode->setLeftAncLocs(cur);

		availNodes.push_back(id);
		NodesVector.push_back(newnode);
		nlins--; id++;
	}
	Root = NodesVector[id-1];
	numInternNodes = id-numTips;
}

int Graph::simuSNP(double* statFreq, gsl_rng* gslr)
{
	double u= gsl_rng_uniform_pos(gslr);
	int SNP;
	if(u<statFreq[0]) SNP = 'A';
	else if(u<(statFreq[0]+statFreq[1])) SNP = 'C';
	else if(u<(statFreq[0]+statFreq[1]+statFreq[2])) SNP = 'G';
	else SNP = 'T';
	return SNP;
}

double Graph::totalTreeLengths(vector<Node*>* tree)
{
	double totalLengths =0;
	vector<Node*>::iterator it;

	assert((int)tree->size()==3 + (numTips-2)*3);
	for(it=tree->begin()+2; it<tree->end(); it+=3)
	{
		totalLengths += (*it)->getTime() - (*(it-2))->getTime();
		totalLengths += (*it)->getTime() - (*(it-1))->getTime();
	}
	return totalLengths;
}


void Graph::addMutations(double mu, double length, vector<double>& phydis, gsl_rng* gslr)
{
	int nmuts;
	int nsites = (int)(length+1);

	double lambda = TotalTime* mu *nsites;
	nmuts = gsl_ran_poisson(gslr, lambda);

	for(int i=0; i<nmuts; i++)
	{
		double pos = (int)(gsl_rng_uniform_pos(gslr)*nsites);
		phydis.push_back(pos);
	}

	sort(phydis.begin(), phydis.end(), Util::compareTwoNumbers);
}

void Graph::printGraph(ofstream& ofs)
{
	ofs<<NodesVector.size()<<endl;
	for(int i=0; i<(int)NodesVector.size(); i++)
	{
		ofs<<NodesVector[i]->getID();
		ofs<<"\t"<<NodesVector[i]->getcoalTime()<<"\t"<<NodesVector[i]->getrecTime()<<"\t";
		if(NodesVector[i]->getleftD()!=NULL)
			ofs<<NodesVector[i]->getleftD()->getID()<<"\t";
		else ofs<<"-1\t";
		if(NodesVector[i]->getrightD()!=NULL)
			ofs<<NodesVector[i]->getrightD()->getID()<<"\t";
		else ofs<<"-1\t";
		if(NodesVector[i]->getleftA()!=NULL)
			ofs<<NodesVector[i]->getleftA()->getID()<<"\t";
		else ofs<<"-1\t";
		if(NodesVector[i]->getrightA()!=NULL)
			ofs<<NodesVector[i]->getrightA()->getID()<<"\t";
		else ofs<<"-1\t";

		ofs<<NodesVector[i]->getBkpoint()<<"\t"<<NodesVector[i]->getFollow()<<"\t";
		NodesVector[i]->printAncLocs(ofs);
	}
}

void Graph::printGraph()
{
	cout<<"Node\tCTime\tRTime\tleftD\trightD\tleftA\trightA\tSequence\n";

	for(int i=0; i<(int)NodesVector.size(); i++)
	{
		cout<<"Node"<<NodesVector[i]->getID();
		cout<<"\t"<<NodesVector[i]->getcoalTime()<<"\t"<<NodesVector[i]->getrecTime()<<"\t";
		if(NodesVector[i]->getleftD()!=NULL)
			cout<<NodesVector[i]->getleftD()->getID()<<"\t";
		else cout<<"NA\t";
		if(NodesVector[i]->getrightD()!=NULL)
			cout<<NodesVector[i]->getrightD()->getID()<<"\t";
		else cout<<"NA\t";
		if(NodesVector[i]->getleftA()!=NULL)
			cout<<NodesVector[i]->getleftA()->getID()<<"\t";
		else cout<<"NA\t";
		if(NodesVector[i]->getrightA()!=NULL)
			cout<<NodesVector[i]->getrightA()->getID()<<"\t";
		else cout<<"NA\t";

		cout<<NodesVector[i]->getBkpoint()<<"\t"<<NodesVector[i]->getFollow()<<"\t";
		NodesVector[i]->printAncLocs();
	}
}

double Graph::moveNode(double delta, int* positions, gsl_rng* gslr)
{
	double propRatio = 1;

	int nnodes;
	double u = gsl_rng_uniform_pos(gslr);
	if(u<0.9) nnodes=1;
	else if(u<0.98) nnodes =2;
	else nnodes = 3;

	for(int i=0; i<nnodes; i++)
	{
		int chosen = numTips + gsl_rng_uniform_int(gslr, numInternNodes);
		Node* moved = NodesVector[chosen];

		if(moved->isRec()) {propRatio *= changeRec(moved, delta, positions, gslr);}
		else propRatio *= changeCoal(moved, delta, positions, gslr);
	}

	return propRatio;
}

double Graph::changeRec(Node* moved, double delta, int* positions, gsl_rng* gslr)
{
	double logprBackw =0, logprForw=0;

	Node* attached; Node* dec; Node* anc;
	if(gsl_rng_uniform_pos(gslr)<0.5) {attached = moved->getleftA(); anc = moved->getrightA(); moved->setrightA(NULL);}
	else {attached = moved->getrightA(); anc = moved->getleftA(); moved->setleftA(NULL);}
	dec = moved->getDec();
	moved->setleftD(NULL); moved->setrightD(NULL);
	if(dec->getleftA()!=NULL && dec->getleftA()->getID()==moved->getID()) dec->setleftA(anc);
	else dec->setrightA(anc);
	if(anc->getleftD()!=NULL && anc->getleftD()->getID()==moved->getID()) anc->setleftD(dec);
	else anc->setrightD(dec);

	int nbr =0;
	double oldtime = moved->getTime();
	for(int i=numTips; i<(int)NodesVector.size(); i++)
	{
		if(NodesVector[i]->getTime()>oldtime)
		{
			if(NodesVector[i]->getleftD()!=NULL && NodesVector[i]->getleftD()->getTime() < oldtime ) nbr++;
			if(NodesVector[i]->getrightD()!=NULL && NodesVector[i]->getrightD()->getTime() < oldtime) nbr++;
		}
	}
	logprBackw += log(1.0/nbr);

	double newtime;
	if(gsl_rng_uniform_pos(gslr)<0.1) newtime = gsl_rng_uniform_pos(gslr)*attached->getTime();
	else
	{
		newtime = fabs(oldtime + gsl_ran_flat(gslr, -delta, delta));
		if(newtime>attached->getTime()) newtime=oldtime;
	}
	assert(newtime>0 && newtime<attached->getTime());

	moved->setrecTime(newtime);
	sort(NodesVector.begin(), NodesVector.end(), Util::compareTwoNodesT);

	vector<decAnc> branches;
	for(int i=numTips; i<(int)NodesVector.size(); i++)
	{
		if(NodesVector[i]->getTime()>newtime)
		{
			if(NodesVector[i]->getleftD()!=NULL && NodesVector[i]->getleftD()->getTime() < newtime )
			{ decAnc abr; abr.dec=NodesVector[i]->getleftD(); abr.anc=NodesVector[i]; branches.push_back(abr);}
			if(NodesVector[i]->getrightD()!=NULL && NodesVector[i]->getrightD()->getTime() < newtime)
			{ decAnc abr; abr.dec=NodesVector[i]->getrightD(); abr.anc=NodesVector[i]; branches.push_back(abr);}
		}
	}

	int chosen = gsl_rng_uniform_int(gslr, (int)branches.size());
	Node* chbr = branches[chosen].anc;
	Node* chbrD = branches[chosen].dec;
	logprForw += log(1.0/(int)branches.size());

	insertNodeBtTwoNodes(chbrD, chbr, moved);

	double propRatio = exp( logprBackw - logprForw);

	for(int i=numTips; i<(int)NodesVector.size(); i++)
	{
		propRatio *= NodesVector[i]->updateAncLocs(false, false, positions, gslr);
		if(propRatio ==0) return 0;
	}

	return propRatio;
}

double Graph::changeCoal(Node* moved, double delta, int* positions, gsl_rng* gslr)
{
	double logprBackw=0, logprForw=0;

	Node* tmproot;
	tmproot= new Node(-1, Root->getTime()+1, 0, numLoci);

	tmproot -> setleftD(Root);
	Root->setleftA(tmproot);

	Node* attached; Node* dec; Node* anc;
	if(gsl_rng_uniform_pos(gslr)<0.5) {attached = moved->getleftD(); dec = moved->getrightD(); moved->setrightD(NULL);}
	else {attached = moved->getrightD(); dec = moved->getleftD(); moved->setleftD(NULL);}
	anc = moved->getAnc();
	moved->setleftA(NULL); moved->setrightA(NULL);

	if(dec->getleftA()!=NULL && dec->getleftA()->getID()==moved->getID()) dec->setleftA(anc);
	else dec->setrightA(anc);
	if(anc->getleftD()!=NULL && anc->getleftD()->getID()==moved->getID()) anc->setleftD(dec);
	else anc->setrightD(dec);

	int nbr =0; double oldtime = moved->getTime();
	for(int i=numTips; i<(int)NodesVector.size(); i++)
	{
		if(NodesVector[i]->getTime()>oldtime)
		{
			if(NodesVector[i]->getleftD()!=NULL && NodesVector[i]->getleftD()->getTime() < oldtime ) nbr++;
			if(NodesVector[i]->getrightD()!=NULL && NodesVector[i]->getrightD()->getTime() < oldtime) nbr++;
		}
	}
	if(tmproot->getDec()->getTime()<oldtime) nbr++;
	logprBackw += log(1.0/nbr);

	double lambda = 1.0/delta;
	double dtPrime = -log(1-gsl_rng_uniform_pos(gslr))/lambda;
	double newtime = attached->getTime() + dtPrime;
	assert(newtime>attached->getTime());
	double dt = oldtime - attached->getTime();
	moved->setcoalTime(newtime);
	sort(NodesVector.begin(), NodesVector.end(), Util::compareTwoNodesT);
	tmproot->setcoalTime(tmproot->getcoalTime()+newtime);

	logprBackw += log(lambda) - lambda*dt;
	logprForw += log(lambda) - lambda*dtPrime;

	vector<decAnc> branches;
	for(int i=numTips; i<(int)NodesVector.size(); i++)
	{
		if(NodesVector[i]->getTime()>newtime)
		{
			if(NodesVector[i]->getleftD()!=NULL && NodesVector[i]->getleftD()->getTime() < newtime )
			{ decAnc abr; abr.dec=NodesVector[i]->getleftD(); abr.anc=NodesVector[i]; branches.push_back(abr);}
			if(NodesVector[i]->getrightD()!=NULL && NodesVector[i]->getrightD()->getTime() < newtime)
			{ decAnc abr; abr.dec=NodesVector[i]->getrightD(); abr.anc=NodesVector[i]; branches.push_back(abr);}
		}
	}
	if(tmproot->getDec()->getTime()<newtime)
	{decAnc abr; abr.dec=tmproot->getDec(); abr.anc=tmproot; branches.push_back(abr);}

	int chosen = gsl_rng_uniform_int(gslr, (int)branches.size());
	Node* chbr = branches[chosen].anc;
	Node* chbrD = branches[chosen].dec;
	logprForw += log(1.0/(int)branches.size());

	insertNodeBtTwoNodes(chbrD, chbr, moved);

	Root = NodesVector[numInternNodes+numTips-1]; Root->setleftA(NULL); Root->setrightA(NULL);
	if(tmproot!=NULL) {delete tmproot; }

	double propRatio = exp( logprBackw - logprForw);

	for(int i=numTips; i<(int)NodesVector.size(); i++)
	{
		propRatio *= NodesVector[i]->updateAncLocs(false, false, positions, gslr);
		if(propRatio ==0) return 0;
	}

	return propRatio;
}

void Graph::getConnections(vector<Node*>& conn, Node* cursor)
{
	conn.clear();
	if(cursor->getleftA()!=NULL) conn.push_back(cursor->getleftA());
	if(cursor->getrightA()!=NULL) conn.push_back(cursor->getrightA());
	if(cursor->getleftD()!=NULL) conn.push_back(cursor->getleftD());
	if(cursor->getrightD()!=NULL) conn.push_back(cursor->getrightD());
	assert((int)conn.size()>=1 && (int)conn.size()<=3);
}

void Graph::insertNodeBtTwoNodes( Node* node1, Node* node2, Node* insertNode)
{
	assert(node1!=NULL && node2!=NULL);

	Node* parent; Node* child;
	if(node1->getTime() < node2->getTime()) {child = node1; parent = node2;}
	else { child = node2; parent=node1;}

	if(child->getleftA()!=NULL && child->getleftA()->getID() == parent->getID()){ child->setleftA(insertNode);}
	else {child->setrightA(insertNode);}
	if(insertNode->isCoal())
	{ if(insertNode->getleftD()==NULL ) insertNode->setleftD(child); else insertNode->setrightD(child);}
	else{ insertNode->setleftD(child);}

	if(parent->getleftD()!=NULL && parent->getleftD()->getID() == child->getID()) { parent->setleftD(insertNode);}
	else { parent->setrightD(insertNode);}
	if(insertNode->isCoal()) { insertNode->setleftA(parent);}
	else{ if(insertNode->getleftA()==NULL) insertNode->setleftA(parent); else insertNode->setrightA(parent);}
}

double Graph::calculateLogprior(double* rho, int* positions)
{
	double logpr=0;
	vector<Node*>::iterator vi;
	vector<decAnc>::iterator ii;

	vector<decAnc> branches;
	for(vi=NodesVector.begin(); vi!=NodesVector.begin()+numTips; vi++)
	{ decAnc abr; abr.dec=(*vi); abr.anc=(*vi)->getAnc(); branches.push_back(abr);}

	int lin=numTips;
	for(vi=NodesVector.begin()+numTips; vi!=NodesVector.end(); vi++)
	{
		double rholen=0;
		for(ii=branches.begin(); ii!=branches.end(); ii++)
		{
			if((*ii).dec->isRec() && (*ii).dec->getleftA()->getID()==(*ii).dec->getrightA()->getID())//isloop
			{
				ALLELE* hap = (*ii).dec->getAncLocs(LEFT);
				int index1 = (*ii).dec->getLeftStart();
				int index2 = (*ii).dec->getLeftEnd();
				for(int i=index1; i<index2-1; i++)
					rholen += (positions[i+1]-positions[i])*rho[i]*PERMB;

				hap = (*ii).dec->getAncLocs(RIGHT);
				index1 = (*ii).dec->getRightStart();
				index2 = (*ii).dec->getRightEnd();
				for(int i=index1; i<index2-1; i++)
					rholen += (positions[i+1]-positions[i])*rho[i]*PERMB;

				ii++;
				assert((*ii).dec->getID()==(*(ii-1)).dec->getID());
			}
			else
			{
				ALLELE* hap;
				int index1, index2;

				if(!(*ii).dec->isRec() || (*ii).dec->getleftA()->getID()==(*ii).anc->getID())
				{hap = (*ii).dec->getAncLocs(LEFT); index1=(*ii).dec->getLeftStart(); index2=(*ii).dec->getLeftEnd();}
				else{hap = (*ii).dec->getAncLocs(RIGHT); index1=(*ii).dec->getRightStart(); index2=(*ii).dec->getRightEnd();}
				assert(index1>=0 && index1<=numLoci && index2>=0 && index2<=numLoci);

				for(int i=index1; i<index2-1; i++) rholen += (positions[i+1]-positions[i])*rho[i]*PERMB;
			}
		}
		assert(lin==(int)branches.size());

		if((*vi)->isCoal())
		{
			double intervTime = ((*vi)->getcoalTime()-(*(vi-1))->getTime());
			logpr += -(rholen/2.0 + (double)lin*(lin-1)/(2))*intervTime;

			int nerase=0;
			for(int i=0; i<2; i++)
			{
				for(ii=branches.begin(); ii!=branches.end(); ii++)
				{ if((*ii).anc->getID()==(*vi)->getID()) {branches.erase(ii); nerase++; break; } }
			}
			decAnc abr; abr.dec=(*vi); abr.anc=(*vi)->getAnc(); branches.push_back(abr);
			if(nerase!=2){ printGraph(); cout<<(*vi)->getID()<<"\t"<<(*vi)->getTime()<<endl; exit(1); }
			lin--;
		}
		else
		{
			double intervTime = (*vi)->getrecTime()-(*(vi-1))->getTime();
			logpr += -(rholen/2.0 + (double)lin*(lin-1)/(2))*intervTime + log(rholen/2.0);

			//get the recombination rate for bkp
			double bkp = (*vi)->getBkpoint();
			double rholeni = -1; double len = -1;
			for(int i=0; i<numLoci-1; i++)
			{
				if(bkp>=positions[i] && bkp<positions[i+1])
				{ rholeni = rho[i]*(positions[i+1]-positions[i])*PERMB; len=positions[i+1]-positions[i]; break;}
			}
			if(rholeni<=0 || rholen<=0 || len<=0)
			{
				cout<<"rholeni = "<<rholeni<<"\trholen = "<<rholen<<"\tlen = "<<endl;
				printGraph();
				cout<<(*vi)->getID()<<endl;
				cout<<bkp<<endl;
			}
			//assert(rholeni>0 && rholen>0 && len>0);
			if(rholeni>rholen)
			{
				cout<<"rholeni = "<<rholeni<<"\trholen = "<<rholen<<endl;
				printGraph();
				cout<<(*vi)->getID()<<endl;
				cout<<bkp<<endl;
			}
			logpr += log(rholeni/rholen * 1.0/len);

			//update branches
			for(ii=branches.begin(); ii!=branches.end(); ii++)
			{ if((*ii).anc->getID()==(*vi)->getID()) {branches.erase(ii); break;} }
			decAnc abr1; abr1.dec=(*vi); abr1.anc=(*vi)->getleftA(); branches.push_back(abr1);
			decAnc abr2; abr2.dec=(*vi); abr2.anc=(*vi)->getrightA(); branches.push_back(abr2);
			lin++;
		}

		if(vi<NodesVector.end()-1 && lin==1) {return 0;}
	}
	assert(lin==1);
	assert((int)branches.size()==1 && branches[0].dec->getID()==Root->getID());

	return logpr;
}


double Graph::logpriorARG(double rholen)
{
	int lin=1;
	double logL=0;
	vector<Node*>::iterator vi;

	for(vi=NodesVector.end()-1; vi!=NodesVector.begin()+numTips-1; vi--)
	{
		if((*vi)->getcoalTime()!=0) lin ++;
		else lin--;
		if(lin==1) return 0;

		if((*vi)->getcoalTime()!=0)
		{
			double intervTime = ((*vi)->getcoalTime()-(*(vi-1))->getTime());
			logL += -(rholen*lin/2.0 + (double)lin*(lin-1)/(2))*intervTime;
		}
		else
		{
			double intervTime = (*vi)->getrecTime()-(*(vi-1))->getTime();
			logL += -(rholen*lin/2.0 + (double)lin*(lin-1)/(2))*intervTime + log(rholen/2.0);
		}
	}
	return logL;
}


bool Graph::containsLoop()
{
	for(int i=numTips; i<numTips+numInternNodes; i++)
	{
		if(NodesVector[i]->isCoal() && NodesVector[i]->getleftD()->getID() == NodesVector[i]->getrightD()->getID())
			return true;
	}
	return false;
}

void Graph::eligibleRecBranches(vector<decAncdir>& branches, double rectime)
{
	vector<Node*>::iterator vi;
	branches.clear();

	for(vi=NodesVector.begin(); vi!=NodesVector.end()-1; vi++)
	{
		if((*vi)->getTime()<rectime)
		{
			Node* lefta = (*vi)->getleftA();
			if(lefta!=NULL && lefta->getTime()>rectime && (*vi)->getLeftEnd()-(*vi)->getLeftStart()>1)
			{
				decAncdir abr; abr.dec=(*vi); abr.ancdir=LEFT;
				branches.push_back(abr);
			}
			Node* righta = (*vi)->getrightA();
			if(righta!=NULL && righta->getTime()>rectime && (*vi)->getRightEnd()-(*vi)->getRightStart()>1)
			{
				decAncdir abr; abr.dec=(*vi); abr.ancdir=RIGHT;
				branches.push_back(abr);
			}
		}
	}
}

void Graph::eligibleCoalBranches(vector<decAncdir>& branches, double coaltime)
{
	vector<Node*>::iterator vi;
	branches.clear();

	for(vi=NodesVector.begin(); vi!=NodesVector.end(); vi++)
	{
		if((*vi)->getTime()<coaltime)
		{
			Node* lefta = (*vi)->getleftA();
			if(lefta!=NULL && lefta->getTime() > coaltime )
			{
				decAncdir abr; abr.dec=(*vi); abr.ancdir=LEFT;
				branches.push_back(abr);
			}
			Node* righta = (*vi)->getrightA();
			if(righta!=NULL && righta->getTime() > coaltime)
			{
				decAncdir abr; abr.dec=(*vi); abr.ancdir=RIGHT;
				branches.push_back(abr);
			}
		}
	}
}

void Graph::eligiblePair(vector<decAncdir>& branches)
{
	vector<Node*>::iterator vi;
	branches.clear();

	for(vi=NodesVector.begin()+numTips; vi!=NodesVector.end(); vi++)
	{
		if((*vi)->isRec())
		{
			Node* lefta = (*vi)->getleftA();
			if(lefta->isCoal() && lefta->getID()!=Root->getID())
			{
				decAncdir abr; abr.dec=(*vi); abr.ancdir=LEFT;
				branches.push_back(abr);
			}
			Node* righta = (*vi)->getrightA();
			if(righta->isCoal() && righta->getID()!=Root->getID() )
			{
				decAncdir abr; abr.dec=(*vi); abr.ancdir=RIGHT;
				branches.push_back(abr);
			}
		}
	}
}

void Graph::insertNode( Node* insertNode, Node* decNode, int ancDir)
{
	Node* parent; Node* child;
	child = decNode;
	if(ancDir==LEFT) parent = child->getleftA();
	else parent = child->getrightA();

	if(ancDir==LEFT) child->setleftA(insertNode);
	else {child->setrightA(insertNode);}
	if(insertNode->isCoal())
	{ if(insertNode->getleftD()==NULL ) insertNode->setleftD(child); else insertNode->setrightD(child);}
	else{ insertNode->setleftD(child);}

	if(parent->getleftD()!=NULL && parent->getleftD()->getID() == child->getID()) { parent->setleftD(insertNode);}
	else { parent->setrightD(insertNode);}
	if(insertNode->isCoal()) { insertNode->setleftA(parent);}
	else{ if(ancDir==LEFT) insertNode->setleftA(parent); else insertNode->setrightA(parent);}
}


double Graph::rotate(gsl_rng* gslr)
{
	for(int i=numTips; i<numTips+numInternNodes; i++)
	{
		if(NodesVector[i]->isRec() && gsl_rng_uniform_pos(gslr)<0.5)
		{
			Node* tmp = NodesVector[i]->getleftA();
			NodesVector[i]->setleftA(NodesVector[i]->getrightA());
			NodesVector[i]->setrightA(tmp);
		}
		if(NodesVector[i]->isCoal() && gsl_rng_uniform_pos(gslr)<0.5)
		{
			Node* tmp = NodesVector[i]->getleftD();
			NodesVector[i]->setleftD(NodesVector[i]->getrightD());
			NodesVector[i]->setrightD(tmp);
		}
	}

	return 1;
}


double Graph::changeBkpointFollow(int* positions, gsl_rng* gslr)
{
	double propRatio =1;
	int chosen = gsl_rng_uniform_int(gslr, numRecs);
	int count=0;
	int signal =0;
	for(int i=numTips; i<(int)NodesVector.size(); i++)
	{
		if(NodesVector[i]->isRec() && signal==0)
		{
			if(count==chosen)
			{
				propRatio *= NodesVector[i]->updateAncLocs(true, true, positions, gslr);
				signal =1;
			}
			count++;
		}
		if(signal==1) propRatio *= NodesVector[i]->updateAncLocs(false, false, positions, gslr);
		if(propRatio ==0) return 0;
	}

	return propRatio;
}

void Graph::changeOneAncSeq(gsl_rng* gslr, double freqChangeAnc)
{
	vector<Node*>** trees;

	trees = new vector<Node*>*[numLoci];

	for(int i=0; i<numLoci; i++)
		trees[i] = new vector<Node*>;

	getTreesFast(trees);

	int nnodes = trees[0]->size();
	assert(nnodes = 3*(numTips-1));

	for(int mk=0; mk<numLoci; mk++)
	{
		if(gsl_rng_uniform_pos(gslr)<freqChangeAnc) //change an allele of the marker tree
		{
			vector<Node*>* markerTree = trees[mk];

			//choose an internal node
			int ch = gsl_rng_uniform_int(gslr, nnodes);
			Node* chosen = *(markerTree->begin()+ch);

			if(!chosen->isTip())
			{
				ALLELE* hap = chosen->getAncLocs(LEFT);
				hap[mk] = Util::randNuc2(hap[mk], gslr);
			}
		}
	}

	for(int i=0; i<numLoci; i++) delete trees[i];
	delete [] trees;
}

int Graph::ranchar(gsl_rng* gslr)
{
	double p = gsl_rng_uniform_pos(gslr);
	if(p<0.25) return'A';
	else if(p>=0.25 && p<0.5) return 'T';
	else if(p>=0.5 && p<0.75) return 'G';
	else return 'C';
}

double Graph::addRecCoal(int* positions, gsl_rng* gslr)
{
	double logprForw =0;
	double logprBackw=0;
	vector<Node*>::iterator vi;

	double rectime, coaltime;
	double t1 = gsl_rng_uniform_pos(gslr)*Root->getTime();
	double t2 = gsl_rng_uniform_pos(gslr)*Root->getTime();
	if(t1<t2) {rectime=t1; coaltime=t2;}
	else {rectime=t2; coaltime=t1;}
	logprForw += log(pow(1.0/Root->getTime(), 2)*2);

	vector<decAncdir> branches;
	eligibleRecBranches(branches, rectime);
	if(branches.empty()) return 0;

	int nbr = (int)branches.size();
	int ch1 = gsl_rng_uniform_int(gslr, nbr);
	Node* brec = branches[ch1].dec; int brecAdir = branches[ch1].ancdir;
	Node* brecA; if(brecAdir==LEFT) brecA=brec->getleftA(); else brecA = brec->getrightA();
	logprForw += log(1.0/nbr);

	eligibleCoalBranches(branches, coaltime);
	int nbr2 = (int)branches.size();
	assert(nbr2>=1);
	int ch2 = gsl_rng_uniform_int(gslr, nbr2);
	Node* bcoal = branches[ch2].dec; int bcoalAdir = branches[ch2].ancdir;
	Node* bcoalA; if(bcoalAdir==LEFT) bcoalA=bcoal->getleftA(); else bcoalA = bcoal->getrightA();
	logprForw += log(1.0/nbr2);

	if(rectime==coaltime)
		rectime -= EPSILON;
	assert(rectime<coaltime);
	assert(rectime>brec->getTime() && rectime<brecA->getTime());
	assert(coaltime>bcoal->getTime() && coaltime<bcoalA->getTime());

	Node* recnode; Node* coalnode;
	recnode= new Node(numInternNodes+numTips, 0, rectime, numLoci);

	coalnode= new Node(numInternNodes+numTips+1, coaltime, 0, numLoci);

	insertNode(recnode, brec, brecAdir);
	if(bcoal->getID()==brec->getID() && bcoalA->getID()==brecA->getID()) //loop
	{
		if(recnode->getleftA()!=NULL) insertNode(coalnode, recnode, LEFT);
		else insertNode(coalnode, recnode, RIGHT);
	}
	else insertNode(coalnode, bcoal, bcoalAdir);

	if(recnode->getleftA()==NULL) recnode->setleftA(coalnode);
	else recnode->setrightA(coalnode);
	if(coalnode->getleftD()==NULL) coalnode->setleftD(recnode);
	else coalnode->setrightD(recnode);

	NodesVector.push_back(recnode);
	NodesVector.push_back(coalnode);
	sort(NodesVector.begin(), NodesVector.end(), Util::compareTwoNodesT);
	numInternNodes +=2; numRecs++;

	ALLELE* vec;
	int st, en;
	if(!brec->isRec() || brec->getleftA()->getID()==recnode->getID())
	{ vec=brec->getAncLocs(LEFT); st=brec->getLeftStart(); en=brec->getLeftEnd();}
	else {vec=brec->getAncLocs(RIGHT); st=brec->getRightStart(); en=brec->getRightEnd();}

	int loc2 = positions[en-1];
	int loc1 = positions[st];
	double u = gsl_rng_uniform_pos(gslr);
	double pos = u*(loc2-loc1)+loc1;
	recnode->setBkpoint(pos);
	if(gsl_rng_uniform_pos(gslr)<0.5) recnode->setFollow(LEFT_LEFT); else recnode->setFollow(LEFT_RIGHT);
	logprForw += log(1.0/(loc2-loc1)*0.5);
	recnode->breakAncLocs(vec, positions);

	double propRatio =1;
	for(int i=numTips; i<(int)NodesVector.size(); i++)
	{
		if(NodesVector[i]->getTime()>rectime)
		{
			propRatio *= NodesVector[i]->updateAncLocs(false, false, positions, gslr);
			if(propRatio ==0) {return 0;}
		}
	}

	eligiblePair(branches);
	assert(!branches.empty());
	logprBackw += log(1.0/(double)branches.size());

	return exp(logprBackw - logprForw) * propRatio;
}

double Graph::deleteRecCoal(int* positions, gsl_rng* gslr)
{
	double logprForw =0, logprBackw=0;
	vector<Node*>::iterator vi;

	vector<decAncdir> branches;
	eligiblePair(branches);
	if(branches.empty()) return 0;

	int chosen = gsl_rng_uniform_int(gslr, (int)branches.size());
	logprForw += log(1.0/(double)branches.size());

	Node* rec = branches[chosen].dec;
	Node* coal;
	int coalDir = branches[chosen].ancdir;
	if(coalDir==LEFT) coal=rec->getleftA(); else coal = rec->getrightA();
	assert(rec->isRec() && coal->isCoal());

	double rectime = rec->getTime();
	double coaltime = coal->getTime();

	if(rec->getleftA()->getID()==coal->getID()) rec->setleftA(NULL);
	else rec->setrightA(NULL);
	if(coal->getleftD()->getID()==rec->getID()) coal->setleftD(NULL);
	else coal->setrightD(NULL);

	Node* brec; Node* brecA; Node* bcoal; Node* bcoalA;
	if(rec->getAnc()->getID()!=coal->getID()) //not a loop
	{brec=rec->getDec(); brecA=rec->getAnc(); bcoal=coal->getDec(); bcoalA=coal->getAnc();}
	else{ brec=rec->getDec(); brecA= coal->getAnc(); bcoal=brec; bcoalA=brecA;}

	ALLELE* vec;
	int st, en;
	if(!brec->isRec() || brec->getleftA()->getID()==rec->getID())
	{ vec=brec->getAncLocs(LEFT); st=brec->getLeftStart(); en=brec->getLeftEnd();}
	else {vec=brec->getAncLocs(RIGHT); st=brec->getRightStart(); en=brec->getRightEnd();}
	logprBackw += log(1.0/(positions[en-1]-positions[st])*0.5);

	Node* anc; Node* dec; Node* cursor;
	for(int i=0; i<2; i++)
	{
		if(i==0) cursor=rec;
		else cursor=coal;

		if(cursor->getAnc()!=NULL)
		{
			anc=cursor->getAnc(); dec=cursor->getDec();

			if(anc->getleftD()!=NULL && anc->getleftD()->getID()==cursor->getID()) anc->setleftD(dec);
			else anc->setrightD(dec);
			if(dec->getleftA()!=NULL && dec->getleftA()->getID()==cursor->getID()) dec->setleftA(anc);
			else dec->setrightA(anc);
		}
		numInternNodes--;
	}
	int nerase=0;
	for(vi=NodesVector.begin(); vi!=NodesVector.end(); vi++)
	{ if((*vi)->getID()==rec->getID()) {NodesVector.erase(vi); nerase++; break;} }
	for(vi=NodesVector.begin(); vi!=NodesVector.end(); vi++)
	{ if((*vi)->getID()==coal->getID()) {NodesVector.erase(vi); nerase++; break;} }
	assert(nerase==2);

	numRecs--;

	delete rec; delete coal;

	sort(NodesVector.begin(), NodesVector.end(), Util::compareTwoNodesT);
	for(int i=numTips; i<numInternNodes+numTips; i++) NodesVector[i]->setID(i);

	double propRatio =1;
	for(int i=numTips; i<(int)NodesVector.size(); i++)
	{
		if(NodesVector[i]->getTime()>rectime)
		{
			propRatio *= NodesVector[i]->updateAncLocs(false, false, positions, gslr);
			if(propRatio ==0) return 0;
		}
	}

	eligibleRecBranches(branches, rectime);
	int nbr = (int)branches.size();
	assert(nbr>0);
	logprBackw += log(1.0/nbr);

	eligibleCoalBranches(branches, coaltime);
	nbr = (int)branches.size();
	assert(nbr>0);
	logprBackw += log(1.0/nbr);

	logprBackw += log(pow(1.0/Root->getTime(), 2)*2);

	return exp(logprBackw - logprForw)*propRatio;
}

double Graph::getTottimeGraph()
{
	double tottime=0;
	int nlins =numTips;
	for(int i=numTips; i<(int)NodesVector.size(); i++)
	{
		tottime += nlins*(NodesVector[i]->getTime() - NodesVector[i-1]->getTime());
		if(NodesVector[i]->isRec()) nlins++;
		else nlins--;
	}
	assert(nlins==1);
	return tottime;
}

Node* Graph::findNode(int id)
{
	for(int i=0; i<(int)NodesVector.size(); i++)
	{
		if(NodesVector[i]->getID()==id) return NodesVector[i];
	}
	return NULL;
}

double Graph::calculateLogllh(double theta, int mk, double* staFreq)
{
	double logllh = 0;

	if(mk<0) logllh = logllhGraph(theta, staFreq);
	else logllh = logllhGraphSingleSite(theta, staFreq, mk);

	return logllh;
}

void Graph::getTreesFast(vector<Node*>** trees)
{
	vector<Node*>::iterator vi;
	vector<ALLELE>::iterator it;

	for(int i=0; i<numLoci; i++) trees[i]->clear();

	for(vi=NodesVector.begin()+numTips; vi!=NodesVector.end(); vi++)
	{
		Node* cursor = (*vi);
		if((*vi)->isRec() || ((*vi)->getleftD()->getID()==(*vi)->getrightD()->getID())) continue;

		ALLELE* hap = cursor->getAncLocs(LEFT);

		vector<ALLELE> coalescedLocs;
		ALLELE* hapdLeft = transHap(cursor->getleftD(), cursor);
		ALLELE* hapdRight = transHap(cursor->getrightD(), cursor);

		for(int i=0; i<numLoci; i++)
		{
			if(hap[i]!=999 && hapdLeft[i]!=999 && hapdRight[i]!=999)	coalescedLocs.push_back(i);
		}

		for(it=coalescedLocs.begin(); it!=coalescedLocs.end(); it++)
		{
			Node* decTrees[2];
			decTrees[0] = cursor->getleftD();
			decTrees[1] = cursor->getrightD();

			int mk = *it;

			for(int i=0; i<2; i++)
			{
				while(decTrees[i]!=NULL)
				{
					if(decTrees[i]->isRec()) decTrees[i]=decTrees[i]->getDec();
					else if(decTrees[i]->isCoal())
					{
						Node* d1 = decTrees[i]->getleftD();
						Node* d2 = decTrees[i]->getrightD();
						ALLELE* hap1;
						ALLELE* hap2;
						if(d1->getID()==d2->getID()) {hap1=d1->getAncLocs(LEFT); hap2=d1->getAncLocs(RIGHT);}
						else { hap1=transHap(d1, decTrees[i]); hap2=transHap(d2, decTrees[i]);}

						if(hap1[mk]!=999 && hap2[mk]!=999) {break;}
						else if (hap1[mk]!=999 && hap2[mk]==999) {decTrees[i] = d1;}
						else if(hap1[mk]==999 && hap2[mk]!=999) {decTrees[i] = d2;}
						else{ cerr<<"error!"<<endl; exit(-1);}
					}
					else {assert(decTrees[i]->isTip()); break;}
				}
			}
			trees[mk]->push_back(decTrees[0]);
			trees[mk]->push_back(decTrees[1]);
			trees[mk]->push_back(cursor);
		}
	}
}

ALLELE* Graph::transHap(Node* dec, Node* cursor)
{
	ALLELE* hap;
	if(!dec->isRec() || dec->getleftA()->getID()==cursor->getID())
	{hap = dec->getAncLocs(LEFT);}
	else {hap = dec->getAncLocs(RIGHT);}
	return hap;
}

double Graph::logllhGraphSingleSite(double theta, double* staFreq, int mk)
{
	//return -1;
	double logllh =0;
	vector<Node*>::iterator vi;
	double brlen =0;

	int nlineages = numTips;

	for(vi=NodesVector.begin()+numTips; vi!=NodesVector.end(); vi++)
	{
		Node* cursor = (*vi);
		if((*vi)->isRec() || ((*vi)->getleftD()->getID()==(*vi)->getrightD()->getID())) continue;

		ALLELE* hap = cursor->getAncLocs(LEFT);

		if(hap[mk]==999) continue;

		ALLELE* hapdLeft = transHap(cursor->getleftD(), cursor);
		ALLELE* hapdRight = transHap(cursor->getrightD(), cursor);

		if(hapdLeft[mk]==999 || hapdRight[mk]==999) continue;

		Node* decTrees[2];
		decTrees[0] = cursor->getleftD();
		decTrees[1] = cursor->getrightD();

		int allele = hap[mk];
		assert(allele!=999);

		ALLELE* hap1;
		ALLELE* hap2;

		for(int i=0; i<2; i++)
		{
			while(decTrees[i]!=NULL)
			{
				if(decTrees[i]->isRec()) decTrees[i]=decTrees[i]->getDec();
				else if(decTrees[i]->isCoal())
				{
					Node* d1 = decTrees[i]->getleftD();
					Node* d2 = decTrees[i]->getrightD();
					if(d1->getID()==d2->getID()) {hap1=d1->getAncLocs(LEFT); hap2=d1->getAncLocs(RIGHT);}
					else { hap1=transHap(d1, decTrees[i]); hap2=transHap(d2, decTrees[i]);}

					if(hap1[mk]!=999 && hap2[mk]!=999) break;
					else if(hap1[mk]!=999 && hap2[mk]==999) decTrees[i] = d1;
					else if(hap1[mk]==999 && hap2[mk]!=999) decTrees[i] = d2;
					else{ cerr<<"error!"<<endl; exit(-1);}
				}
				else {assert(decTrees[i]->isTip()); break;}
			}//while loop
		}//finish finding two descendants

		int alle[2];
		alle[0]=-1; alle[1]=-1;
		for(int i=0; i<2; i++)
		{
			ALLELE* hapd = decTrees[i]->getAncLocs(LEFT);
			alle[i] = hapd[mk];
			assert(alle[i]!=999);

			double lambda = theta*0.5*(cursor->getTime()-decTrees[i]->getTime());
			double prnomut = exp(-lambda);

			double staf;
			if(alle[i]==(int)'A') staf=staFreq[0];
			else if(alle[i]==(int)'C') staf=staFreq[1];
			else if(alle[i]==(int)'G') staf=staFreq[2];
			else if(alle[i]==(int)'T') staf=staFreq[3];
			else { cerr<<"Nucleotide ("<<(char)alle[i]<<") does not exist."<<endl; exit(0); }

			if(allele!=alle[i]) {logllh += log((1-prnomut)*staf);}
			else logllh += log(prnomut + (1-prnomut)*staf);

			brlen += cursor->getTime()-decTrees[i]->getTime();

			if(i==0)
			{
				nlineages--;
				if(nlineages==1)//root of the current marker tree
				{
					double staf;
					if(allele==(int)'A') staf=staFreq[0];
					else if(allele==(int)'C') staf=staFreq[1];
					else if(allele==(int)'G') staf=staFreq[2];
					else if(allele==(int)'T') staf=staFreq[3];
					else { cerr<<"Nucleotide ("<<(char)alle[i]<<") does not exist."<<endl; exit(0); }
					logllh += log(staf);
				}
			}
		}
	}//loop over all internal nodes

	assert(nlineages==1);
	logllh -= log(1-exp(-theta*0.5*brlen));

	return logllh;
}


double Graph::logllhGraph(double theta, double* staFreq)
{
	//return -1;
	double logllh =0;
	vector<Node*>::iterator vi;
	vector<ALLELE>::iterator it;

	int nlineages[numLoci];
	for(int i=0; i<numLoci; i++)
	{
		nlineages[i] = numTips;
	}

	double brlen[numLoci];
	for(int i=0; i<numLoci; i++) brlen[i]=0;
	for(vi=NodesVector.begin()+numTips; vi!=NodesVector.end(); vi++)
	{
		Node* cursor = (*vi);
		if((*vi)->isRec() || ((*vi)->getleftD()->getID()==(*vi)->getrightD()->getID())) continue;

		ALLELE* hap = cursor->getAncLocs(LEFT);

		vector<ALLELE> coalescedLocs;
		ALLELE* hapdLeft = transHap(cursor->getleftD(), cursor);
		ALLELE* hapdRight = transHap(cursor->getrightD(), cursor);

		if(hapdLeft==NULL || hapdRight==NULL) continue;

		for(int i=0; i<numLoci; i++)
		{
			if(hap[i]!=999 && hapdLeft[i]!=999 && hapdRight[i]!=999) coalescedLocs.push_back(i);
		}

		for(it=coalescedLocs.begin(); it!=coalescedLocs.end(); it++)
		{
			Node* decTrees[2];
			decTrees[0] = cursor->getleftD();
			decTrees[1] = cursor->getrightD();

			int mk = *it;
			int allele = hap[mk];
			assert(allele=='A' || allele=='T' || allele=='G' || allele=='C');

			for(int i=0; i<2; i++)
			{
				while(decTrees[i]!=NULL)
				{
					if(decTrees[i]->isRec()) decTrees[i]=decTrees[i]->getDec();
					else if(decTrees[i]->isCoal())
					{
						Node* d1 = decTrees[i]->getleftD();
						Node* d2 = decTrees[i]->getrightD();
						ALLELE* hap1;
						ALLELE* hap2;
						if(d1->getID()==d2->getID()) {hap1=d1->getAncLocs(LEFT); hap2=d1->getAncLocs(RIGHT);}
						else { hap1=transHap(d1, decTrees[i]); hap2=transHap(d2, decTrees[i]);}

						if(hap1!=NULL && hap1[mk]!=999 && ((hap2==NULL)||(hap2!=NULL && hap2[mk]==999))) decTrees[i] = d1;
						else if(hap2!=NULL && hap2[mk]!=999 && ((hap1==NULL)||(hap1!=NULL && hap1[mk]==999))) decTrees[i] = d2;
						else if(hap1!=NULL && hap2!=NULL && hap1[mk]!=999 && hap2[mk]!=999) break;
						else{ cerr<<"error!"<<endl; exit(-1);}
					}
					else {assert(decTrees[i]->isTip()); break;}
				}//while loop
			}//finish finding two descendants

			int alle[2];
			for(int i=0; i<2; i++)
			{
				ALLELE* hapd = decTrees[i]->getAncLocs(LEFT);
				alle[i] = hapd[mk];
				assert(alle[i]=='A' || alle[i]=='T' || alle[i]=='G' || alle[i]=='C');

				double lambda = theta*0.5*(cursor->getTime()-decTrees[i]->getTime());
				double prnomut = exp(-lambda);

				double staf;
				if(alle[i]==(int)'A') staf=staFreq[0];
				else if(alle[i]==(int)'C') staf=staFreq[1];
				else if(alle[i]==(int)'G') staf=staFreq[2];
				else if(alle[i]==(int)'T') staf=staFreq[3];
				else { cerr<<"Nucleotide ("<<(char)alle[i]<<") does not exist."<<endl; exit(0); }

				if(allele!=alle[i]) logllh += log((1-prnomut)*staf);
				else logllh += log(prnomut + (1-prnomut)*staf);

				brlen[mk]+=cursor->getTime()-decTrees[i]->getTime();

				if(i==0)
				{
					nlineages[mk]--;
					if(nlineages[mk]==1)
					{
						double staf;
						if(allele==(int)'A') staf=staFreq[0];
						else if(allele==(int)'C') staf=staFreq[1];
						else if(allele==(int)'G') staf=staFreq[2];
						else if(allele==(int)'T') staf=staFreq[3];
						else { cerr<<"Nucleotide ("<<(char)alle[i]<<") does not exist."<<endl; exit(0); }
						logllh += log(staf);
					}
				}
			}//two descendants
		}//loop over all coalescence loci
	}//loop over all internal nodes

	for(int i=0; i<numLoci; i++) logllh -= log(1-exp(-theta*0.5*brlen[i]));

	return logllh;
}

int Util::compQsortFreq(const void* a , const void* b)
{
	double tmp = (*(MapHap**)a)->frequency - (*(MapHap**)b)->frequency;
	if(tmp<0) return 1;
	else if(tmp>0) return -1;
	else return 0;
}

bool Util::compareTwoNodesT(Node* a, Node* b)
{
	return a->getTime() < b->getTime();
}

bool Util::compareTwoNodesID(Node* a, Node* b)
{
	return a->getID() < b->getID();
}

bool Util::compareFirstConnection(nodeAncestors* a, nodeAncestors* b)
{
	return a->ancestors[0]->getTime() < b->ancestors[0]->getTime();
}

bool Util::compareTwoLocs(locAlle* a, locAlle* b)
{
	return a->loc<b->loc;
}

bool Util::compareTwoNumbers(double a, double b)
{
	return a<b;
}

int Util::randNuc(gsl_rng* gslr)
{
	double p = gsl_rng_uniform_pos(gslr);
	if(p<0.25) return'A';
	else if(p>=0.25 && p<0.5) return 'T';
	else if(p>=0.5 && p<0.75) return 'G';
	else return 'C';
}

int Util::randNuc2(int oldType, gsl_rng* gslr)
{
	double u = gsl_rng_uniform_pos(gslr);
	double x=1.0/3.0; double y=2.0/3.0;

	switch (oldType)
	{
		case 'A': if(u<x) return 'T'; else if(u>x && u<y) return 'G'; else return 'C';
		case 'T': if(u<x) return 'G'; else if(u>x && u<y) return 'C'; else return 'A';
		case 'G': if(u<x) return 'C'; else if(u>x && u<y) return 'A'; else return 'T';
		default: if(u<x) return 'A'; else if(u>x && u<y) return 'T'; else return 'G';
	}
}

int Util::randNuc3(int allele1, int allele2, gsl_rng* gslr)
{
	assert(allele1=='A' || allele1=='C' ||allele1=='G'||allele1=='T');
	assert(allele2=='A' || allele2=='C' ||allele2=='G'||allele2=='T');
	assert(allele1!=allele2);

	double p = gsl_rng_uniform_pos(gslr);

	if((allele1=='A' && allele2=='C') || (allele2=='A' && allele1=='C')) {if(p<0.5) return 'G'; else return 'T';}
	else if((allele1=='A' && allele2=='G') || (allele2=='A' && allele1=='G')) {if(p<0.5) return 'C'; else return 'T';}
	else if((allele1=='A' && allele2=='T') || (allele2=='A' && allele1=='T')) {if(p<0.5) return 'C'; else return 'G';}
	else if((allele1=='C' && allele2=='G') || (allele2=='C' && allele1=='G')) {if(p<0.5) return 'A'; else return 'T';}
	else if((allele1=='C' && allele2=='T') || (allele2=='C' && allele1=='T')) {if(p<0.5) return 'A'; else return 'G';}
	else if((allele1=='G' && allele2=='T') || (allele2=='G' && allele1=='T')) {if(p<0.5) return 'A'; else return 'C';}
	else {cout<<"allele doesn't exist!"<<endl; exit(1);}
}

double Util::logGamma(double x, double shape, double scale)
{
	double res = (shape-1)*log(x) - shape*log(scale) - x/scale - gsl_sf_lngamma(shape);

	return res;
}

double Util::logNormal(double x, double mu, double sigma)
{
	double res = -log(SQR2PI*sigma*x) - pow(log(x)-mu,2)/(2*sigma*sigma);

	return res;
}

double Util::logBeta(double x, double a, double b)
{
	double res = (a-1)*log(x) + (b-1)*log(1-x) - gsl_sf_lnbeta (a, b);

	return res;
}

int Util::ResetFinetuneSteps(double* Pjump, double* finetune, int nsteps)
{
	int j, verybadstep=0;
	double PjumpOpt = 0.30; /* this is the optimum for the Bactrian move. */

	cout<<"\n\nCurrent Pjump: ";
	for(j=0; j<nsteps; j++)
		cout<<" %8.5f"<<Pjump[j];
	cout<<"\nCurrent finetune:";
	for(j=0; j<nsteps; j++)
		cout<<" %8.5f"<<finetune[j];

	for(j=0; j<nsteps; j++)
	{
		if(Pjump[j]==-1) {} //do nothing, if the parameter is never got chance to be proposed for changing
		else if(Pjump[j] < 0.001)
		{
			finetune[j] /= 100;
			verybadstep = 1;
		}
		else if(Pjump[j] > 0.999)
		{
			finetune[j] *= 100;
			verybadstep = 1;
		}
		else
		{
			finetune[j] *= tan(PI/2*Pjump[j]) / tan(PI/2*PjumpOpt);
		}

		if(finetune[j]>100000) finetune[j]=100000;
		if(finetune[j]<1e-5) finetune[j]=1e-5;
	}

	cout<<"\nNew finetune: ";
	for(j=0; j<nsteps; j++)
		cout<<" %8.5f"<<finetune[j];
	cout<<"\n\n";

	return(verybadstep);
}

