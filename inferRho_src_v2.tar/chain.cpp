/*
	Copyright, Ying Wang, yingw09@gmail.com
*/

#include "chain.h"

//declare a new chain, allocate memories and initialize the chain
Chain::Chain(double bt, int ng, int* ns, int* nm, int** pd, int*** seqm, int start, int end, double* statf, vector<missSnp>* miss, int*** snps):
beta(bt), nGraphs(ng), nSeq(ns), nMarkers(nm), phyDis(pd), seqMatrix(seqm), startInterv(start), endInterv(end), statFreq(statf), missing(miss), SNPs(snps)
{
	//allocate memory
	genealogy = new vector<Graph*>;
	rho = new double*[nGraphs];
	rhoBackg = new double*[nGraphs];

	for(int tau=0; tau<nGraphs; tau++)
	{
		rho[tau] = new double[nMarkers[tau]-1];
		rhoBackg[tau] = new double[nMarkers[tau]-1];
	}

	hotspots = new vector<Hotspot*>;

	lambdaHalfWidth = 1/500.0;
	lambdaSimZ = 1/5000.0;
	hotspMuZ = 9;
	hotspSigmaZ = 1;
	hotspLambdaX1 = 1/50000.0;
	hotspLambdaX2 = 1/1000.0;
	thetaShape = 0.25;
	thetaScale = 2;

	numProp = new int[NC];
	numAcc = new int[NC];

	gslr = gsl_rng_alloc(gsl_rng_taus2);
	gsl_rng_set(gslr, time(NULL)+beta);

	initializeChain();
}

Chain::~Chain()
{
	for(int tau=0; tau<nGraphs; tau++)
		delete genealogy->at(tau);
	genealogy->clear();
	delete genealogy;

	for(int tau=0; tau<nGraphs; tau++)
	{
		delete [] rho[tau];
		delete [] rhoBackg[tau];
	}
	delete [] rho;
	delete [] rhoBackg;

	clearHotspots(hotspots);
	delete hotspots;

	gsl_rng_free(gslr);

	delete [] numProp;
	delete [] numAcc;
}

void Chain::setupMixingPar(double dnode, double dhap, double danc, double dhs, double dhsg, double drb, int drbl, double dt)
{
	deltaNode = dnode;
	dHap = dhap;
	dAnc = danc;
	deltaHotsp = dhs;
	deltaHotspGlobal = dhsg;
	deltaRhoBackg = drb;
	deltaRhoBackgLambda = drbl;
	deltaTheta = dt;
}

void Chain::simulateGenealogy()
{
	for(int tau=0; tau<nGraphs; tau++)
	{
		Graph* agraph;
		agraph = new Graph(nSeq[tau], nMarkers[tau]);

		agraph->simuBNTree(seqMatrix[tau], gslr);
		genealogy->push_back(agraph);
	}
}

void Chain::initializeChain()
{
	simulateGenealogy();

	for(int tau=0; tau<nGraphs; tau++)
	{
		for(int i=0; i<nMarkers[tau]-1; i++)
			rhoBackg[tau][i] = gsl_rng_uniform_pos(gslr)*200;
	}

	rhoBackgLambda = 1 + gsl_rng_uniform_int(gslr, 300);
	theta = gsl_rng_uniform_pos(gslr)*10;

	for(int tau=0; tau<nGraphs; tau++)
		updateRho(rho[tau], rhoBackg[tau], hotspots, phyDis[tau], nMarkers[tau]);

	for(int i=0; i<NC; i++) {numProp[i]=0; numAcc[i]=0;}

	double ll, lp;
	for(int tau=0; tau<nGraphs; tau++)
	{
		ll = genealogy->at(tau)->calculateLogllh(theta, -1, statFreq);
		genealogy->at(tau)->setLogllh(ll);

		lp = genealogy->at(tau)->calculateLogprior(rho[tau], phyDis[tau]);
		genealogy->at(tau)->setLogprior(lp);
	}
}

void Chain::updateRho(double* rhov, double* rhobgv, vector<Hotspot*>* hsp, int* phyDis_, int nMarkers_)
{
	for(int i=0; i<nMarkers_-1; i++)
	{
		rhov[i] = rhobgv[i];
	}

	int nhs = (int)hsp->size();

	for(int i=0; i<nhs; i++)
	{
		Hotspot* curhs = hsp->at(i);
		if(curhs->X1 > phyDis_[nMarkers_-1]) break;

		if(curhs->X1 > phyDis_[0])
		{
			int index = -1;
			for(int j=0; j<nMarkers_-1; j++)
			{
				if(phyDis_[j]<=curhs->X1 && phyDis_[j+1]>curhs->X1) {index = j; break;}
			}
			assert(index>=0 && phyDis_[index+1]>=curhs->X1);
			double hsStart = curhs->X1;
			double hsEnd = curhs->X2;
			for(int j=index; j<nMarkers_-1; j++)
			{
				double l1; double l2;
				if(phyDis_[j]<hsStart) l1=hsStart; else l1=phyDis_[j];
				if(phyDis_[j+1]>hsEnd) l2=hsEnd; else l2=phyDis_[j+1];

				rhov[j] = ((l2-l1)*(rhov[j]+curhs->Z) + (phyDis_[j+1]-phyDis_[j]-(l2-l1))*rhov[j])/(phyDis_[j+1]-phyDis_[j]);

				if(phyDis_[j+1]>hsEnd) break;
			}
		}
	}
}

void Chain::printRho()
{
	for(int tau=0; tau<nGraphs; tau++)
	{
		for(int i=0; i<nMarkers[tau]-1; i++)
		{
			cout<<rho[tau][i]<<" ";
		}
		cout<<endl;
	}
	cout<<endl;
}

void Chain::modifyGenealogy()
{
	double alpha, logpriorGp, logpriorG, llhGp, llhG;
	int chg = gsl_rng_uniform_int(gslr, nGraphs);

	Graph* G = genealogy->at(chg);
	Graph* Gp = new Graph(*G);

	double prAdd, prDelete, prChange;
	if(G->getnumRecs()==0) {prAdd=0.8; prDelete =0; prChange=0.2;}
	else if(G->getnumRecs()==MAXNRECS) {prAdd=0; prDelete=0.8; prChange=0.2;}
	else {prAdd=0.4; prDelete=0.4; prChange=0.2;}

	double pr= gsl_rng_uniform_pos(gslr);

	double propRatio;
	if(pr<prChange)
	{
		propRatio = Gp->moveNode(deltaNode, phyDis[chg], gslr);
	}
	else if(pr<prChange+prAdd)
	{
		propRatio = Gp->addRecCoal(phyDis[chg], gslr);
		if(G->getnumRecs()==MAXNRECS-1) propRatio *=2;
		if(G->getnumRecs()==0) propRatio *=0.5;
	}
	else
	{
		propRatio = Gp->deleteRecCoal(phyDis[chg], gslr);
		if(G->getnumRecs()==MAXNRECS) propRatio *=0.5;
		if(G->getnumRecs()==1) propRatio *=2;
	}

	if(propRatio==0){ alpha=0;}
	else
	{
		logpriorGp = Gp->calculateLogprior(rho[chg], phyDis[chg]);
		Gp->setLogprior(logpriorGp);

		if(logpriorGp==0) {alpha=0; }
		else
		{
			logpriorG = G->getLogprior();

			llhGp = Gp->calculateLogllh(theta, -1, statFreq);
			Gp->setLogllh(llhGp);
			llhG = G->getLogllh();

			alpha = propRatio* exp((logpriorGp - logpriorG) + beta*(llhGp - llhG));
		}
	}

	numProp[GEN]++;
	if(gsl_rng_uniform_pos(gslr)<alpha)
	{
		delete genealogy->at(chg);
		genealogy->at(chg) = Gp;
		numAcc[GEN]++;
	}
	else delete Gp;
}

void Chain::modifyTree()
{
	int chg = gsl_rng_uniform_int(gslr, nGraphs);
	Graph* G = genealogy->at(chg);
	if(G->getnumRecs()==0) return;

	Graph* Gp = new Graph(*G);

	double alpha;
	double propRatio = Gp->changeBkpointFollow(phyDis[chg], gslr);

	if(propRatio==0) alpha=0;
	else
	{
		double llhGp =	Gp->calculateLogllh(theta, -1, statFreq);
		Gp->setLogllh(llhGp);
		double lpp = Gp->calculateLogprior(rho[chg], phyDis[chg]);
		Gp->setLogprior(lpp);

		double logpriorRatio = lpp - G->getLogprior();

		double logllhRatio = beta*(llhGp - G->getLogllh());
		alpha = propRatio * exp(logpriorRatio + logllhRatio);
	}

	numProp[TREE]++;
	if(gsl_rng_uniform_pos(gslr)<alpha)
	{
		delete genealogy->at(chg);
		genealogy->at(chg) = Gp;
		numAcc[TREE]++;
	}
	else delete Gp;
}


void Chain::modifyMissingData()
{
	assert(!missing->empty());
	int chosen = gsl_rng_uniform_int(gslr, (int)missing->size());
	int tau = missing->at(chosen).graph;
	Graph* Glocal = genealogy->at(tau);
	Node* node = Glocal->findNode(missing->at(chosen).chrid);
	int mk = missing->at(chosen).locus;

	double llhG = Glocal->calculateLogllh(theta, mk, statFreq);

	ALLELE* vec = node->getAncLocs(LEFT);
	int bk = vec[mk];
	assert(SNPs[tau][mk][0]!=SNPs[tau][mk][1]);

	double propRatio = 1;
	if(bk==SNPs[tau][mk][0] || bk==SNPs[tau][mk][1]) propRatio *= 0.45;
	else propRatio *= 0.05;

	double u = gsl_rng_uniform_pos(gslr);
	if(u<0.45) {vec[mk]=SNPs[tau][mk][0]; propRatio /= 0.45;}
	else if(u<0.9) {vec[mk]=SNPs[tau][mk][1];propRatio /= 0.45;}
	else {vec[mk] = Util::randNuc3(SNPs[tau][mk][0], SNPs[tau][mk][1], gslr); propRatio /= 0.05;}

	double llhGp = Glocal->calculateLogllh(theta, mk, statFreq);

	double alpha;
	if(llhGp==0) alpha=0;
	else {alpha = propRatio*exp(beta*(llhGp-llhG));}

	numProp[MISS]++;
	if(gsl_rng_uniform_pos(gslr)<alpha)
	{
		Glocal->setLogllh(Glocal->getLogllh() + llhGp-llhG);
		numAcc[MISS]++;
	}
	else {vec[mk]=bk;}
}

void Chain::modifyHaplotype()
{
	int chg = gsl_rng_uniform_int(gslr, nGraphs);
	Graph* G = genealogy->at(chg);

	int chosen = gsl_rng_uniform_int(gslr, (int)(nSeq[chg]*0.5));
	Node* node1 = G->findNode(chosen*2);
	Node* node2 = G->findNode(chosen*2+1);
	assert(node1->getID()==chosen*2 && node2->getID()==chosen*2+1);

	ALLELE* vec1 = node1->getAncLocs(LEFT);
	ALLELE* vec2 = node2->getAncLocs(LEFT);

	int* hap1 = new int[nMarkers[chg]];
	int* hap2 = new int[nMarkers[chg]];
	for(int mk=0; mk<nMarkers[chg]; mk++)
	{
		hap1[mk] = vec1[mk];
		hap2[mk] = vec2[mk];
	}

	double llhG = G->getLogllh();

	for(int mk=0; mk<nMarkers[chg]; mk++)
	{
		if(gsl_rng_uniform_pos(gslr)<dHap)
		{
			int bk = vec1[mk]; vec1[mk]=vec2[mk]; vec2[mk]=bk;
		}
	}

	double llhGp = G->calculateLogllh(theta, -1, statFreq);

	double alpha;
	if(llhGp==0) alpha=0;
	else {alpha = exp(beta*(llhGp-llhG));}

	numProp[HAP]++;
	if(gsl_rng_uniform_pos(gslr)<alpha)
	{
		G->setLogllh(llhGp);
		numAcc[HAP]++;
	}
	else
	{
		for(int mk=0; mk<nMarkers[chg]; mk++)
		{
			vec1[mk] = hap1[mk];
			vec2[mk] = hap2[mk];
		}
	}
	delete [] hap1;
	delete [] hap2;
}

void Chain::modifyAncestralStates()
{
	int chg = gsl_rng_uniform_int(gslr, nGraphs);
	Graph* G = genealogy->at(chg);

	Graph* Gp = new Graph(*G);

	Gp->changeOneAncSeq(gslr, dAnc);

	double llhGp = Gp->calculateLogllh(theta, -1, statFreq);
	Gp->setLogllh(llhGp);
	double llhG = G->getLogllh();

	double alpha = exp(beta*(llhGp-llhG));

	numProp[ANC]++;
	if(gsl_rng_uniform_pos(gslr)<alpha)
	{
		delete genealogy->at(chg);
		genealogy->at(chg) = Gp;

		numAcc[ANC]++;
	}
	else delete Gp;
}

void Chain::changeRhoBackgLambda()
{
	int rhoBackgLambdaPrime;
	double propRatio;
	assert(rhoBackgLambda>=1 && rhoBackgLambda<=MAXLAMBDA);

	int lowb = rhoBackgLambda - deltaRhoBackgLambda;
	int highb = rhoBackgLambda + deltaRhoBackgLambda+1;
	if(lowb<1) lowb=1;
	if(highb>MAXLAMBDA+1) highb=MAXLAMBDA+1;
	int invf = highb-lowb;
	rhoBackgLambdaPrime = lowb + gsl_rng_uniform_int(gslr, invf);

	lowb = rhoBackgLambdaPrime - deltaRhoBackgLambda;
	highb = rhoBackgLambdaPrime + deltaRhoBackgLambda+1;
	if(lowb<1) lowb=1;
	if(highb>MAXLAMBDA+1) highb=MAXLAMBDA+1;
	int invb = highb-lowb;
	propRatio = (double)invf/(double)invb;

	double logpriorPrime = logPriorRhoBackg(rhoBackg, rhoBackgLambdaPrime);
	double logprior = logPriorRhoBackg(rhoBackg, rhoBackgLambda);

	double alpha = exp(logpriorPrime-logprior)*propRatio;

	numProp[RHOBGL]++;
	if(gsl_rng_uniform_pos(gslr)<alpha)
	{
		numAcc[RHOBGL]++;
		rhoBackgLambda=rhoBackgLambdaPrime;
	}
}

void Chain::changeRhoBackgRate()
{
	int chg = gsl_rng_uniform_int(gslr, nGraphs);
	Graph* G = genealogy->at(chg);

	double* rhoBackgPrime = new double[nMarkers[chg]-1];

	for(int i=0; i<nMarkers[chg]-1; i++)
	{
		if(gsl_rng_uniform_pos(gslr)<0.2)
			rhoBackgPrime[i] = fabs(rhoBackg[chg][i]+ gsl_ran_flat(gslr, -deltaRhoBackg, deltaRhoBackg));
		else rhoBackgPrime[i] = rhoBackg[chg][i];
	}

	double* rhoPrime = new double[nMarkers[chg]-1];
	updateRho(rhoPrime, rhoBackgPrime, hotspots, phyDis[chg], nMarkers[chg]);

	double logpriorPrime=0, logprior=0;
	for(int i=0; i<nMarkers[chg]-1; i++)
	{
		logpriorPrime += log(1.0/rhoBackgLambda) - 1.0/rhoBackgLambda*rhoBackgPrime[i];
		logprior += log(1.0/rhoBackgLambda) - 1.0/rhoBackgLambda*rhoBackg[chg][i];
	}

	double lpp = G->calculateLogprior(rhoPrime, phyDis[chg]);
	logpriorPrime += lpp;
	logprior += G->getLogprior();

	double alpha = exp(logpriorPrime-logprior);

	numProp[RHOBGR]++;
	if(gsl_rng_uniform_pos(gslr)<alpha)
	{
		for(int i=0; i<nMarkers[chg]-1; i++)
		{
			rhoBackg[chg][i]=rhoBackgPrime[i];
			rho[chg][i]=rhoPrime[i];
		}
		G->setLogprior(lpp);
		numAcc[RHOBGR]++;
	}
	delete [] rhoBackgPrime;
	delete [] rhoPrime;
}

void Chain::modifyRhoBackg()
{
	double U = gsl_rng_uniform_pos(gslr);
	if(U<0.1) changeRhoBackgLambda();
	else changeRhoBackgRate();
}

void Chain::changeHotspAreaConst()
{
	vector<Hotspot*>* hotspotsPrime = new vector<Hotspot*>;
	double propRatio = proposeHotspots(hotspotsPrime, hotspots);

	double logprior = logPriorHotspots(hotspots);
	double logpriorPrime = logPriorHotspots(hotspotsPrime);

	double alpha = exp(logpriorPrime - logprior) * propRatio;

	if(gsl_rng_uniform_pos(gslr)<alpha)
	{
		copyHotspots(hotspots, hotspotsPrime);
	}
	clearHotspots(hotspotsPrime);
	delete hotspotsPrime;
}

void Chain::changeHotspot(double prChange)
{
	double logpriorHotsp = logPriorHotspots(hotspots);

	int nhs = (int)hotspots->size();
	assert(nhs>0);
	int chosen = gsl_rng_uniform_int(gslr, nhs);

	double lowb, highb;
	if(chosen==0) lowb = startInterv; else lowb = hotspots->at(chosen-1)->X2;
	if(chosen==nhs-1) highb = endInterv; else highb = hotspots->at(chosen+1)->X1;

	Hotspot* backup = new Hotspot;
	backup->X1=hotspots->at(chosen)->X1;
	backup->X2=hotspots->at(chosen)->X2;
	backup->Z=hotspots->at(chosen)->Z;
	double y1 = backup->X1;
	double y2 = backup->X2;

	double y1prime, y2prime;
	y1prime = fabs(y1+ gsl_ran_flat(gslr,-100, 100));
	if(y1prime<=lowb || y1prime>=y2) {y1prime=y1;}
	y2prime = fabs(y2+gsl_ran_flat(gslr,-50, 50));
	if(y2prime<=y1prime || y2prime>=highb) {y2prime=y2;}

	hotspots->at(chosen)->X1 = y1prime;
	hotspots->at(chosen)->X2 = y2prime;
	hotspots->at(chosen)->Z = fabs(hotspots->at(chosen)->Z + gsl_ran_flat(gslr, -deltaHotsp, deltaHotsp));

	double* probs = new double[3];
	getProposalProb(probs);
	double propRatio = probs[0]/prChange;
	delete [] probs;

	double** rhoPrime = new double*[nGraphs];

	double logprior = 0; double logpriorPrime = 0;
	double* lpp = new double[nGraphs];

	for(int i=0; i<nGraphs; i++)
	{
		rhoPrime[i] = new double[nMarkers[i]-1];

		updateRho(rhoPrime[i], rhoBackg[i], hotspots, phyDis[i], nMarkers[i]);

		bool changed = false;
		for(int j=0; j<nMarkers[i]-1; j++)
		{
			if(fabs(rhoPrime[i][j] - rho[i][j])>EPSILON) {changed=true; break;}
		}

		if(changed)
		{
			lpp[i] = genealogy->at(i)->calculateLogprior(rhoPrime[i], phyDis[i]);
			logpriorPrime += lpp[i];
			logprior += genealogy->at(i)->getLogprior();
		}
		else {lpp[i]=genealogy->at(i)->getLogprior();}
	}
	double logpriorHotspPrime = logPriorHotspots(hotspots);

	double alpha = exp((logpriorPrime-logprior) + (logpriorHotspPrime-logpriorHotsp))*propRatio;

	numProp[HOTSPC]++;
	if(gsl_rng_uniform_pos(gslr)<alpha)
	{
		for(int i=0; i<nGraphs; i++)
		{
			for(int j=0; j<nMarkers[i]-1; j++) rho[i][j] = rhoPrime[i][j];
			genealogy->at(i)->setLogprior(lpp[i]);
		}
		numAcc[HOTSPC]++;
	}
	else
	{
		hotspots->at(chosen)->X1=backup->X1;
		hotspots->at(chosen)->X2=backup->X2;
		hotspots->at(chosen)->Z=backup->Z;
	}
	delete backup;
	for(int i=0; i<nGraphs; i++) delete [] rhoPrime[i];
	delete [] rhoPrime;
	delete [] lpp;
}

void Chain::changeHotspotGlobal(double prChange)
{
	double logpriorHotsp = logPriorHotspots(hotspots);

	int nhs = (int)hotspots->size();
	assert(nhs>0);
	int chosen = gsl_rng_uniform_int(gslr, nhs);

	double lowb, highb;
	if(chosen==0) lowb = startInterv; else lowb = hotspots->at(chosen-1)->X2;
	if(chosen==nhs-1) highb = endInterv; else highb = hotspots->at(chosen+1)->X1;

	Hotspot* backup = new Hotspot;
	backup->X1=hotspots->at(chosen)->X1;
	backup->X2=hotspots->at(chosen)->X2;
	backup->Z=hotspots->at(chosen)->Z;

	double logprForw=0; double logprBackw =0;
	double y1, y2, B;
	y1 = gsl_rng_uniform_pos(gslr)*(highb-lowb) + lowb;
	if(highb-y1 < y1-lowb) B = highb-y1; else B = y1-lowb;
	if(highb==endInterv && highb-y1 < y1-lowb)
	{
		double prExceed = exp(-lambdaHalfWidth*(highb-y1));
		if(gsl_rng_uniform_pos(gslr)<prExceed) { y2 = highb-y1; logprForw += log(prExceed);}
		else
		{
			y2 = -1.0/lambdaHalfWidth * log(1-gsl_rng_uniform_pos(gslr)*(1-exp(-lambdaHalfWidth*B)));
			logprForw += log(1-prExceed) + log(lambdaHalfWidth) - lambdaHalfWidth*y2 - log(1-exp(-lambdaHalfWidth*B));
		}
	}
	else
	{
		y2 = -1.0/lambdaHalfWidth * log(1-gsl_rng_uniform_pos(gslr)*(1-exp(-lambdaHalfWidth*B)));
		logprForw += log(lambdaHalfWidth) - lambdaHalfWidth*y2 - log(1-exp(-lambdaHalfWidth*B));
	}
	hotspots->at(chosen)->X1 = y1-y2;
	hotspots->at(chosen)->X2 = y1+y2;
	hotspots->at(chosen)->Z = fabs(hotspots->at(chosen)->Z + gsl_ran_flat(gslr, -deltaHotspGlobal, deltaHotspGlobal));

	y1 = 0.5*(backup->X1+backup->X2);
	y2 = 0.5*(backup->X2-backup->X1);
	if(highb-y1 < y1-lowb) B = highb-y1; else B = y1-lowb;
	if(chosen==nhs-1 && highb-y1 < y1-lowb)
	{
		double prExceed = exp(-lambdaHalfWidth*(highb-y1));
		if(fabs(y2-(highb-y1))<1e-8) logprBackw += log(prExceed);
		else logprBackw += log(1-prExceed) + log(lambdaHalfWidth) - lambdaHalfWidth*y2 - log(1-exp(-lambdaHalfWidth*B));
	}
	else logprBackw += log(lambdaHalfWidth) - lambdaHalfWidth*y2 - log(1-exp(-lambdaHalfWidth*B));

	double propRatio = exp(logprBackw-logprForw);

	double* probs = new double[3];
	getProposalProb(probs);
	propRatio *= probs[0]/prChange;
	delete [] probs;

	double** rhoPrime = new double*[nGraphs];
	double* lpp = new double[nGraphs];
	double logprior = 0; double logpriorPrime = 0;

	for(int i=0; i<nGraphs; i++)
	{
		rhoPrime[i] = new double[nMarkers[i]-1];

		updateRho(rhoPrime[i], rhoBackg[i], hotspots, phyDis[i], nMarkers[i]);

		bool changed = false;
		for(int j=0; j<nMarkers[i]-1; j++)
		{
			if(fabs(rhoPrime[i][j] - rho[i][j])>EPSILON) {changed=true; break;}
		}

		if(changed)
		{
			lpp[i] = genealogy->at(i)->calculateLogprior(rhoPrime[i], phyDis[i]);
			logpriorPrime += lpp[i];
			logprior += genealogy->at(i)->getLogprior();
		}
		else lpp[i] = genealogy->at(i)->getLogprior();
	}
	double logpriorHotspPrime = logPriorHotspots(hotspots);

	double alpha = exp((logpriorPrime-logprior)+(logpriorHotspPrime-logpriorHotsp))*propRatio;

	numProp[HOTSPCG]++;
	if(gsl_rng_uniform_pos(gslr)<alpha)
	{
		for(int i=0; i<nGraphs; i++)
		{
			for(int j=0; j<nMarkers[i]-1; j++) rho[i][j] = rhoPrime[i][j];
			genealogy->at(i)->setLogprior(lpp[i]);
		}
		numAcc[HOTSPCG]++;
	}
	else
	{
		hotspots->at(chosen)->X1=backup->X1;
		hotspots->at(chosen)->X2=backup->X2;
		hotspots->at(chosen)->Z=backup->Z;
	}
	delete backup;
	for(int i=0; i<nGraphs; i++) delete [] rhoPrime[i];
	delete [] rhoPrime;
	delete [] lpp;
}


void Chain::insertHotspot(double prInsert)
{
	double logpriorHotsp = logPriorHotspots(hotspots);
	int nhs = (int)hotspots->size();
	int chosen;

	double logprForw=0, logprBackw=0;

	if(nhs>0 && fabs(hotspots->at(nhs-1)->X2 - endInterv) < EPSILON)
	{chosen = gsl_rng_uniform_int(gslr, nhs);}
	else { chosen = gsl_rng_uniform_int(gslr, nhs+1); }

	double lowb, highb;
	if(chosen==0) lowb = startInterv; else lowb = hotspots->at(chosen-1)->X2;
	if(chosen==nhs) highb = endInterv; else highb = hotspots->at(chosen)->X1;

	Hotspot* insertedhs = new Hotspot;

	double y1, y2, B, z;
	y1 = gsl_rng_uniform_pos(gslr)*(highb-lowb) + lowb;
	logprForw += log(1.0/(highb-lowb));

	if(highb-y1 < y1-lowb) B = highb-y1; else B = y1-lowb;
	y2 = -1.0/lambdaHalfWidth * log(1-gsl_rng_uniform_pos(gslr)*(1-exp(-lambdaHalfWidth*B)));
	logprForw += log(lambdaHalfWidth) - lambdaHalfWidth*y2 - log(1-exp(-lambdaHalfWidth*B));

	z = -1.0/lambdaSimZ * log(1-gsl_rng_uniform_pos(gslr));
	logprForw += log(lambdaSimZ) - lambdaSimZ*z;

	insertedhs->X1 = y1-y2;
	insertedhs->X2 = y1+y2;
	insertedhs->Z = z;

	double propRatio = exp(logprBackw-logprForw);
	double jacobian = 2;

	hotspots->insert(hotspots->begin()+chosen, insertedhs);

	double* probs = new double[3];
	getProposalProb(probs);
	propRatio *= probs[2]/prInsert;
	delete [] probs;

	double** rhoPrime = new double*[nGraphs];
	double* lpp = new double[nGraphs];

	double logprior = 0; double logpriorPrime = 0;
	for(int i=0; i<nGraphs; i++)
	{
		rhoPrime[i] = new double[nMarkers[i]-1];

		updateRho(rhoPrime[i], rhoBackg[i], hotspots, phyDis[i], nMarkers[i]);

		bool changed = false;
		for(int j=0; j<nMarkers[i]-1; j++)
		{
			if(fabs(rhoPrime[i][j] - rho[i][j])>EPSILON) {changed=true; break;}
		}
		if(changed)
		{
			lpp[i] = genealogy->at(i)->calculateLogprior(rhoPrime[i], phyDis[i]);
			logpriorPrime += lpp[i];
			logprior += genealogy->at(i)->getLogprior();
		}
		else lpp[i] = genealogy->at(i)->getLogprior();
	}

	double logpriorHotspPrime = logPriorHotspots(hotspots);
	double alpha = exp((logpriorPrime-logprior)+(logpriorHotspPrime-logpriorHotsp))*propRatio*jacobian;

	numProp[HOTSPA]++;
	if(gsl_rng_uniform_pos(gslr)<alpha)
	{
		for(int i=0; i<nGraphs; i++)
		{
			for(int j=0; j<nMarkers[i]-1; j++) rho[i][j] = rhoPrime[i][j];
			genealogy->at(i)->setLogprior(lpp[i]);
		}
		numAcc[HOTSPA]++;
	}
	else
	{
		Hotspot* hs = *(hotspots->begin()+chosen);
		hotspots->erase(hotspots->begin()+chosen);
		delete hs;
	}
	for(int i=0; i<nGraphs; i++) delete [] rhoPrime[i];
	delete [] rhoPrime;
	delete [] lpp;
}

void Chain::deleteHotspot(double prDelete)
{
	double logpriorHotsp = logPriorHotspots(hotspots);
	int nhs = (int)hotspots->size();
	int chosen;
	Hotspot* removedhs;

	assert(nhs>0);
	double logprForw=0, logprBackw=0;
	if(nhs>1 && fabs(hotspots->at(nhs-1)->X2 - endInterv) < EPSILON)
		chosen = gsl_rng_uniform_int(gslr, nhs-1);
	else chosen = gsl_rng_uniform_int(gslr, nhs);

	removedhs = hotspots->at(chosen);
	hotspots->erase(hotspots->begin()+chosen);
	nhs--;

	double lowb, highb;
	if(chosen==0) lowb = startInterv; else lowb = hotspots->at(chosen-1)->X2;
	if(chosen==nhs) highb = endInterv; else highb = hotspots->at(chosen)->X1;

	double y1, y2, B, z;
	y1 = 0.5*(removedhs->X1+removedhs->X2);
	y2 = 0.5*(removedhs->X2-removedhs->X1);

	logprBackw += log(1.0/(highb-lowb));

	if(highb-y1 < y1-lowb) B = highb-y1; else B = y1-lowb;
	logprBackw += log(lambdaHalfWidth) - lambdaHalfWidth*y2 - log(1-exp(-lambdaHalfWidth*B));

	z = removedhs->Z;
	logprBackw += log(lambdaSimZ) - lambdaSimZ*z;

	double propRatio = exp(logprBackw-logprForw);
	double jacobian = 0.5;

	double* probs = new double[3];
	getProposalProb(probs);
	propRatio *= probs[1]/prDelete;
	delete [] probs;

	double** rhoPrime = new double*[nGraphs];
	double* lpp = new double[nGraphs];

	double logprior = 0; double logpriorPrime = 0;
	for(int i=0; i<nGraphs; i++)
	{
		rhoPrime[i] = new double[nMarkers[i]-1];

		updateRho(rhoPrime[i], rhoBackg[i], hotspots, phyDis[i], nMarkers[i]);

		bool changed = false;
		for(int j=0; j<nMarkers[i]-1; j++)
		{
			if(fabs(rhoPrime[i][j] - rho[i][j])>EPSILON) {changed=true; break;}
		}
		if(changed)
		{
			lpp[i] = genealogy->at(i)->calculateLogprior(rhoPrime[i], phyDis[i]);
			logpriorPrime += lpp[i];
			logprior += genealogy->at(i)->getLogprior();
		}
		else lpp[i] = genealogy->at(i)->getLogprior();
	}

	double logpriorHotspPrime = logPriorHotspots(hotspots);
	double alpha = exp((logpriorPrime-logprior)+(logpriorHotspPrime-logpriorHotsp))*propRatio*jacobian;

	numProp[HOTSPD]++;
	if(gsl_rng_uniform_pos(gslr)<alpha)
	{
		for(int i=0; i<nGraphs; i++)
		{
			for(int j=0; j<nMarkers[i]-1; j++) rho[i][j] = rhoPrime[i][j];
			genealogy->at(i)->setLogprior(lpp[i]);
		}
		delete removedhs;
		numAcc[HOTSPD]++;
	}
	else
	{
		int nhs = hotspots->size();
		if(nhs==0 || chosen==nhs) hotspots->push_back(removedhs);
		else hotspots->insert(hotspots->begin()+chosen, removedhs);
	}
	for(int i=0; i<nGraphs; i++) delete [] rhoPrime[i]; delete [] rhoPrime;
	delete [] lpp;
}

void Chain::modifyHotspot()
{
	if(gsl_rng_uniform_pos(gslr)<0.1) {changeHotspAreaConst();}
	else
	{
		double* probs = new double[3];
		getProposalProb(probs);
		double prChange=probs[0], prInsert=probs[1], prDelete=probs[2];

		double U = gsl_rng_uniform_pos(gslr);

		if(U<prChange)
		{
			if(gsl_rng_uniform_pos(gslr)<0.1)
			{changeHotspotGlobal(prChange);}
			else {changeHotspot(prChange);}
		}
		else if(U<prChange+prInsert) {insertHotspot(prInsert);}
		else {deleteHotspot(prDelete);}

		delete [] probs;
	}
}

void Chain::getProposalProb(double* probs)
{
	int nhs = (int)hotspots->size();

	if(nhs==0) {probs[0]=0; probs[1]=1; probs[2]=0;}
	else if(nhs==MAXNHS)
	{
		if(nhs==1 && fabs(hotspots->at(0)->X2 - endInterv)<EPSILON)
		{ probs[0]=1; probs[1]=0; probs[2]=0; }
		else { probs[0] = 0.7; probs[1]=0; probs[2]=0.3; }
	}
	else
	{
		if(nhs==1 && fabs(hotspots->at(0)->X2 - endInterv)<EPSILON)
		{probs[0]=0.2; probs[1]=0.8; probs[2]=0;}
		else {probs[0]=0.5; probs[1]=0.2; probs[2]=0.3;}
	}
}

void Chain::modifyTheta()
{
	double dTheta = gsl_ran_flat(gslr, -deltaTheta, deltaTheta);
	double thetaPrime = fabs(theta+dTheta);

	double logllhPrime =0; double logllh=0; double* lpp = new double[nGraphs];
	for(int tau=0; tau<nGraphs; tau++)
	{
		lpp[tau] = genealogy->at(tau)->calculateLogllh(thetaPrime, -1, statFreq);
		logllhPrime += lpp[tau];
		logllh += genealogy->at(tau)->getLogllh();
	}
	double logpriorRatio = logPriorTheta(thetaPrime) - logPriorTheta(theta);

	double alpha = exp(beta*(logllhPrime - logllh)+logpriorRatio);

	numProp[THE]++;
	if(gsl_rng_uniform_pos(gslr)<alpha)
	{
		theta = thetaPrime;
		for(int tau=0; tau<nGraphs; tau++)
		{
			genealogy->at(tau)->setLogllh(lpp[tau]);
		}
		numAcc[THE]++;
	}
}

double Chain::logPriorTheta(double the)
{
	double lp = Util::logGamma(the, thetaShape, thetaScale);
	return lp;
}

void Chain::setupProb(double prgen, double prtree, double prmiss, double prhap, double pranc, double prrhobg, double prhotsp, double prtheta)
{
	prGen = prgen;
	prTree = prtree;
	prMiss = prmiss;
	prHap = prhap;
	prAnc = pranc;
	prRhoBackg = prrhobg;
	prHotsp = prhotsp;
	prTheta = prtheta;
}

void Chain::modifyChain(int num)
{
	for(int i=0; i<num; i++)
	{
		double U = gsl_rng_uniform_pos(gslr);

		if(U<prGen) {modifyGenealogy();}
		else if(U<prGen+prTree) {modifyTree();}
		else if(U<prGen+prTree+prMiss){modifyMissingData();}
		else if(U<prGen+prTree+prMiss+prHap) {modifyHaplotype();}
		else if(U<prGen+prTree+prMiss+prHap+prAnc) {modifyAncestralStates();}
		else if(U<prGen+prTree+prMiss+prHap+prAnc+prRhoBackg) {modifyRhoBackg();}
		else if(U<prGen+prTree+prMiss+prHap+prAnc+prRhoBackg+prHotsp) {modifyHotspot();}
		else {modifyTheta();}

		if(i%1000==0)
		{
			assert(fabs(genealogy->at(0)->getLogllh()-genealogy->at(0)->calculateLogllh(theta, -1, statFreq))<0.000001);
			assert(fabs(genealogy->at(0)->getLogprior()-genealogy->at(0)->calculateLogprior(rho[0], phyDis[0]))<0.000001);
		}
	}
}

void Chain::copyHotspots(vector<Hotspot*>* newhsvec, vector<Hotspot*>* hsvec)
{
	int nhs = (int)hsvec->size();

	clearHotspots(newhsvec);

	for(int i=0; i<nhs; i++)
	{
		Hotspot* hs = new Hotspot;
		hs->X1 = hsvec->at(i)->X1;
		hs->X2 = hsvec->at(i)->X2;
		hs->Z = hsvec->at(i)->Z;
		newhsvec->push_back(hs);
	}
}

void Chain::clearHotspots(vector<Hotspot*>* hsvec)
{
	vector<Hotspot*>::iterator it;
	for(it=hsvec->begin(); it!=hsvec->end(); it++)
	{
		delete (*it);
	}
	hsvec->clear();
}

void Chain::printHotspots()
{
	cout<<"Hotspots: "<<hotspots->size()<<endl;

	vector<Hotspot*>::iterator it;
	for(it=hotspots->begin(); it!=hotspots->end(); it++)
		cout<<(*it)->X1<<"\t"<<(*it)->X2<<"\t"<<(*it)->Z<<endl;
	cout<<endl;
}

void Chain::printHotspots(ofstream& ofs, int iter)
{
	ofs<<iter<<"\t"<<hotspots->size()<<endl;

	vector<Hotspot*>::iterator it;
	for(it=hotspots->begin(); it!=hotspots->end(); it++)
		ofs<<(*it)->X1<<"\t"<<(*it)->X2<<"\t"<<(*it)->Z<<endl;
	ofs<<endl;
}

void Chain::printHotspots(vector<Hotspot*>* hsp)
{
	cout<<hsp->size()<<": ";

	vector<Hotspot*>::iterator it;
	for(it=hsp->begin(); it!=hsp->end(); it++)
		cout<<(*it)->X1<<"\t"<<(*it)->X2<<"\t"<<(*it)->Z<<endl;
	cout<<endl;
}

double Chain::logPriorHotspots(vector<Hotspot*>* hsp)
{
	double logprior = 0;
	int nhs = (int)hsp->size();

	for(int i=0; i<nhs; i++)
	{
		double x1Pre;
		if(i==0) x1Pre = startInterv; else x1Pre = hsp->at(i-1)->X2;
		double x1 = hsp->at(i)->X1;
		double x2 = hsp->at(i)->X2;
		if(x1Pre>x1 || x1>x2)
		{
			cout<<x1Pre<<">"<<x1<<"\tor\t"<<x1<<">"<<x2<<endl;
			exit(1);
		}

		logprior += log(hotspLambdaX1) - hotspLambdaX1*(x1-x1Pre);
		if(x2==endInterv) logprior += - hotspLambdaX2*(x2-x1);
		else logprior += log(hotspLambdaX2) - hotspLambdaX2*(x2-x1);

		logprior += Util::logNormal(hsp->at(i)->Z, hotspMuZ, hotspSigmaZ);
	}

	if(nhs==0) logprior += -hotspLambdaX1*(endInterv-startInterv);
	else if(hsp->at(nhs-1)->X2<endInterv) logprior += - hotspLambdaX1*(endInterv-hsp->at(nhs-1)->X2);

	return logprior;
}

void Chain::clearGenealogy(vector<Graph*>* gen)
{
	vector<Graph*>::iterator it;
	for(it=gen->begin(); it!=gen->end(); it++)
		delete (*it);
	gen->clear();
}

void Chain::copyGenealogy(vector<Graph*>* newgen, vector<Graph*>* gen)
{
	vector<Graph*>::iterator it;
	for(it=newgen->begin(); it!=newgen->end(); it++)
		delete (*it);
	newgen->clear();

	for(it=gen->begin(); it!=gen->end(); it++)
	{
		Graph* G = new Graph(*(*it));
		newgen->push_back(G);
	}
}

double Chain::logPriorGenealogy()
{
	double logprior =0;
	vector<Graph*>::iterator it;

	for(int i=0; i<nGraphs; i++)
	{
		logprior += genealogy->at(i)->getLogprior();
	}
	return logprior;
}

void Chain::copyRate(double** newRho, double** givenRho)
{
	for(int i=0; i<nGraphs; i++)
	{
		for(int j=0; j<nMarkers[i]-1; j++)
			newRho[i][j]=givenRho[i][j];
	}
}

double Chain::logllhGenealogy()
{
	double logllh =0;
	for(int i=0; i<nGraphs; i++)
	{
		logllh += genealogy->at(i)->getLogllh();
	}
	return logllh;
}


void Chain::recomGenealogy(vector<double>* recom)
{
	for(int tau=0; tau<nGraphs; tau++)
	{
		vector<Node*> nodes = genealogy->at(tau)->getNodesVector();
		int nnodes = (int)nodes.size();

		double startint = phyDis[tau][0];
		double endint = phyDis[tau][nMarkers[tau]-1];
		if(nGraphs==1) assert(startint==startInterv && endint==endInterv);

		for(int j=0; j<nnodes; j++)
		{
			if(nodes[j]->isRec()) recom->push_back(nodes[j]->getBkpoint());
		}
	}
	sort(recom->begin(), recom->end(), Util::compareTwoNumbers);
}


void Chain::treeLengths(double** trlen)
{
	for(int i=0; i<nGraphs; i++)
	{
		vector<Node*>** trees = new vector<Node*>*[nMarkers[i]];

		for(int j=0; j<nMarkers[i]; j++)
			trees[j] = new vector<Node*>;

		genealogy->at(i)->getTreesFast(trees);
		for(int j=0; j<nMarkers[i]; j++)
		{
			trlen[i][j] = genealogy->at(i)->totalTreeLengths(trees[j]);
		}

		for(int j=0; j<nMarkers[i]; j++) delete trees[j];
		delete [] trees;
	}
}

double Chain::proposeHotspots(vector<Hotspot*>* hspPrime, vector<Hotspot*>* hsp)
{
	copyHotspots(hspPrime, hsp);

	int nhs = (int)hspPrime->size();
	double propRatio = 1;
	for(int i=0; i<nhs; i++)
	{
		if(gsl_rng_uniform_pos(gslr)<0.5) continue;

		double x1 = hspPrime->at(i)->X1;
		double x2 = hspPrime->at(i)->X2;
		double z = hspPrime->at(i)->Z;

		for(int tau=0; tau<nGraphs; tau++)
		{
			for(int k=1; k<nMarkers[tau]; k++)
			{
				if(x1>phyDis[tau][k-1] && x2<phyDis[tau][k]) //eligible to modify
				{
					if((i>0 && hspPrime->at(i-1)->X2 > phyDis[tau][k-1]) || (i<=nhs-2 && hspPrime->at(i+1)->X1 < phyDis[tau][k])) continue;

					double area = (x2-x1)*z;
					double lowb = phyDis[tau][k-1];
					double highb = phyDis[tau][k];
					double B, y1, y2;

					y1 = gsl_rng_uniform_pos(gslr)*(highb-lowb) + lowb; //uniform(lb, hb)
					if(highb-y1 < y1-lowb) B = highb-y1; else B = y1-lowb;
					y2 = -1.0/lambdaHalfWidth * log(1-gsl_rng_uniform_pos(gslr)*(1-exp(-lambdaHalfWidth*B)));
					double logprForw = log(lambdaHalfWidth) - lambdaHalfWidth*y2 - log(1-exp(-lambdaHalfWidth*B));

					hspPrime->at(i)->X1 = y1-y2;
					hspPrime->at(i)->X2 = y1+y2;
					hspPrime->at(i)->Z = area/(hspPrime->at(i)->X2-hspPrime->at(i)->X1);

					y1 = 0.5*(hsp->at(i)->X1+hsp->at(i)->X2);
					y2 = 0.5*(hsp->at(i)->X2-hsp->at(i)->X1);
					if(highb-y1 < y1-lowb) B = highb-y1; else B = y1-lowb;
					double logprBackw = log(lambdaHalfWidth) - lambdaHalfWidth*y2 - log(1-exp(-lambdaHalfWidth*B));

					propRatio *= exp(logprBackw-logprForw);
					break;
				}
			}
		}
	}
	return propRatio;
}

void Chain::outputAccProb(ofstream& ofs)
{
	if(numProp[GEN]>0) ofs<<(double)numAcc[GEN]/numProp[GEN]<<" "; else ofs<<"NA ";
	if(numProp[TREE]>0) ofs<<(double)numAcc[TREE]/numProp[TREE]<<" "; else ofs<<"NA ";
	if(numProp[MISS]>0) ofs<<(double)numAcc[MISS]/numProp[MISS]<<" "; else ofs<<"NA ";
	if(numProp[HAP]>0) ofs<<(double)numAcc[HAP]/numProp[HAP]<<" "; else ofs<<"NA ";
	if(numProp[ANC]>0) ofs<<(double)numAcc[ANC]/numProp[ANC]<<" "; else ofs<<"NA ";
	if(numProp[HOTSPC]>0) ofs<<(double)numAcc[HOTSPC]/numProp[HOTSPC]<<" "; else ofs<<"NA ";
	if(numProp[HOTSPCG]>0) ofs<<(double)numAcc[HOTSPCG]/numProp[HOTSPCG]<<" "; else ofs<<"NA ";
	if(numProp[HOTSPA]>0) ofs<<(double)numAcc[HOTSPA]/numProp[HOTSPA]<<" "; else ofs<<"NA ";
	if(numProp[HOTSPD]>0) ofs<<(double)numAcc[HOTSPD]/numProp[HOTSPD]<<" "; else ofs<<"NA ";
	if(numProp[RHOBGR]>0) ofs<<(double)numAcc[RHOBGR]/numProp[RHOBGR]<<" "; else ofs<<"NA ";
	if(numProp[RHOBGL]>0) ofs<<(double)numAcc[RHOBGL]/numProp[RHOBGL]<<" "; else ofs<<"NA ";
	if(numProp[THE]>0) ofs<<(double)numAcc[THE]/numProp[THE]<<" "; else ofs<<"NA ";
	if(numProp[SWAP]>0) ofs<<(double)numAcc[SWAP]/numProp[SWAP]<<" "; else ofs<<"NA ";
}

void Chain::adjMixingParameters()
{
	double* pJump = new double[5];
	double* finetune = new double[5];

	for(int i=0; i<5; i++) pJump[i]=0;
	finetune[0] = dHap;
	finetune[1] = dAnc;
	finetune[2] = deltaRhoBackg;
	finetune[3] = deltaRhoBackgLambda;
	finetune[4] = deltaTheta;

	if(numProp[HAP]>0) pJump[0] = (double)numAcc[HAP]/numProp[HAP]; else pJump[0]=-1;
	if(numProp[ANC]>0) pJump[1] = (double)numAcc[ANC]/numProp[ANC]; else pJump[1]=-1;
	if(numProp[RHOBGR]>0) pJump[2] = (double)numAcc[RHOBGR]/numProp[RHOBGR]; else pJump[2]=-1;
	if(numProp[RHOBGL]>0) pJump[3] = (double)numAcc[RHOBGL]/numProp[RHOBGL]; else pJump[3]=-1;
	if(numProp[THE]>0) pJump[4] = (double)numAcc[THE]/numProp[THE]; else pJump[4]=-1;

	Util::ResetFinetuneSteps(pJump, finetune, 5);

	dHap = finetune[0];
	dAnc = finetune[1];
	deltaRhoBackg = finetune[2];
	deltaRhoBackgLambda = (int)finetune[3];
	if(deltaRhoBackgLambda<=0) deltaRhoBackgLambda=1;
	deltaTheta = finetune[4];

	cout<<"deltaNode="<<deltaNode<<", dHap="<<dHap<<", dAnc="<<dAnc;
	cout<<", deltaHotsp=" <<deltaHotsp<<", deltaHotspGlobal="<<deltaHotspGlobal;
	cout<<", deltaRhoBackg="<<deltaRhoBackg<<", deltaRhoBackgLambda="<<deltaRhoBackgLambda;
	cout<<", deltaTheta="<<deltaTheta<<endl;

	numAcc[HAP]=0; numProp[HAP]=0;
	numAcc[ANC]=0; numProp[ANC]=0;
	numAcc[RHOBGR]=0; numProp[RHOBGR]=0;
	numAcc[RHOBGL]=0; numProp[RHOBGL]=0;
	numAcc[THE]=0; numProp[THE]=0;

	delete [] pJump;
	delete [] finetune;
}

double Chain::adjDeltaTemp(double deltaTemp)
{
	double* pJump = new double[1];
	double* finetune = new double[1];

	finetune[0] = deltaTemp;
	if(numProp[SWAP]>0) pJump[0] = (double)numAcc[SWAP]/numProp[SWAP];
	else pJump[0]=-1;

	Util::ResetFinetuneSteps(pJump, finetune, 1);
	double dt = finetune[0];

	numAcc[SWAP]=0; numProp[SWAP]=0;
	delete [] pJump;
	delete [] finetune;

	return dt;
}

void Chain::printMixingParameters(ofstream& ofs)
{
 	ofs<<deltaNode<<"\t"<<dHap<<"\t"<<dAnc<<"\t";
	ofs<<deltaHotsp<<"\t"<<deltaHotspGlobal<<"\t";
	ofs<<deltaRhoBackg<<"\t"<<deltaRhoBackgLambda<<"\t";
	ofs<<deltaTheta;
}

void Chain::printBeta(ofstream& ofs)
{
	ofs<<beta;
}

double Chain::grandTMRCA()
{
	double tmrca = genealogy->at(0)->getTMRCA();

	for(int tau=1; tau<nGraphs; tau++)
	{
		double age = genealogy->at(tau)->getTMRCA();
		if(age>tmrca) tmrca = age;
	}
	return tmrca;
}

void Chain::markerTMRCAs(double* tmrcas)
{
	vector<Node*>::iterator vi;
	int p = 0;
	for(int i=0; i<nGraphs; i++)
	{
		vector<Node*>** trees;
		trees = new vector<Node*>*[nMarkers[i]];

		for(int j=0; j<nMarkers[i]; j++) trees[j] = new vector<Node*>;

		genealogy->at(i)->getTreesFast(trees);

		for(int j=0; j<nMarkers[i]; j++)
		{
			tmrcas[p] = (*(trees[j]->end()-1))->getTime();

			for(vi=trees[j]->begin(); vi!=trees[j]->end()-1; vi++)
			{
				if((*vi)->getTime()>tmrcas[p]) {cout<<"error"<<endl; exit(1);}
			}
			p++;
		}

		for(int j=0; j<nMarkers[i]; j++) delete trees[j];
		delete [] trees;
	}
}

double Chain::logPriorRhoBackg(double** rhobg, double rhobglambda)
{
	double logprior=0;
	for(int tau=0; tau<nGraphs; tau++)
	{
		for(int i=0; i<nMarkers[tau]-1; i++)
			logprior += log(1.0/rhobglambda) - 1.0/rhobglambda*rhobg[tau][i];
	}

	return logprior;
}

void Chain::printGenealogy()
{
	for(int tau=0; tau<nGraphs; tau++)
	{
		genealogy->at(tau)->printGraph();
		cout<<endl;
	}
	cout<<endl;
}


void Chain::printGenealogy(ofstream& ofstr)
{
	ofstr.precision(9);
	for(int tau=0; tau<nGraphs; tau++)
	{
		genealogy->at(tau)->printGraph(ofstr);
		ofstr<<endl;
	}
	ofstr<<endl;
}

void Chain::sampleHaplotypes(chrHaps** postHap)
{
	vector<haplotypeCount*>::iterator vi;
	for(int tau=0; tau<nGraphs; tau++)
	{
		int nloci = nMarkers[tau];

		for(int chr=0; chr<nSeq[tau]; chr++)
		{
			Node* atip = genealogy->at(tau)->findNode(chr);
			ALLELE* vec = atip->getAncLocs(LEFT);

			int* tiphap = new int[nloci];
			for(int i=0; i<nloci; i++) {tiphap[i]=vec[i];}

			bool hapexit = false;
			for(vi=postHap[tau][chr].haps.begin(); vi!=postHap[tau][chr].haps.end(); vi++)
			{
				if(hapsAreSame((*vi)->haplotype, tiphap, nloci))
				{
					hapexit = true;
					(*vi)->count++;
					break;
				}
			}//loop over all the entries in postHap
			if(!hapexit) //add the new haplotype to the vector
			{
				haplotypeCount* anewhap = new haplotypeCount;
				anewhap->haplotype = new int[nloci];

				for(int i=0; i<nloci; i++) anewhap->haplotype[i]=tiphap[i];
				anewhap->count = 1;
				postHap[tau][chr].haps.push_back(anewhap);
			}
			delete tiphap;
		}//loop over all tips
	}//loop over all graphs
}

bool Chain::hapsAreSame(int* hap1, int* hap2, int nloci)
{
	for(int i=0; i<nloci; i++)
	{
		if(hap1[i]!=hap2[i]){return false;}
	}
	return true;
}

void Chain::sampleMissingBases()
{
	vector<missSnp>::iterator vi;
	int base;

	for(vi=missing->begin(); vi!=missing->end(); vi++)
	{
		Node* atip = genealogy->at((*vi).graph)->findNode((*vi).chrid);
		ALLELE* vec = atip->getAncLocs(LEFT);
		base = vec[(*vi).locus];
		assert(base=='A' || base=='C' || base=='G' || base=='T');
		if(base=='A') (*vi).freq[0]++;
		else if(base=='C') (*vi).freq[1]++;
		else if(base=='G') (*vi).freq[2]++;
		else (*vi).freq[3]++;
	}
}

void Chain::sampleRoot(rootHaps* postRoot)
{
	vector<haplotypeCount*>::iterator vi;
	for(int tau=0; tau<nGraphs; tau++)
	{
		int nloci = nMarkers[tau];

		Node* root = genealogy->at(tau)->getRoot();
		ALLELE* vec = root->getAncLocs(LEFT);

		int* roothap = new int[nloci];
		for(int i=0; i<nloci; i++) {roothap[i]=vec[i];}

		bool hapexit = false;
		for(vi=postRoot[tau].haps.begin(); vi!=postRoot[tau].haps.end(); vi++)
		{
			if(hapsAreSame((*vi)->haplotype, roothap, nloci))
			{
				hapexit = true;
				(*vi)->count++;
				break;
			}
		}//loop over all the entries in postRoot

		if(!hapexit) //add the new haplotype to the vector
		{
			haplotypeCount* anewhap = new haplotypeCount;
			anewhap->haplotype = roothap;
			anewhap->count = 1;
			postRoot[tau].haps.push_back(anewhap);
		}
		else delete roothap;
	}//loop over all graphs
}

void Chain::printRec(ofstream& ofsRec, int iter)
{
	vector<double>* recom = new vector<double>;
	recomGenealogy(recom);
	int nrec = (int)recom->size();

	ofsRec<<iter<<"\t";
	for(int i=0; i<nrec; i++)
	{
		ofsRec<<recom->at(i);
		if(i<nrec-1) ofsRec<<"\t";
	}
	ofsRec<<endl;
}

void Chain::printRho(ofstream& ofs, int iter)
{
	ofs<<iter<<"\t";
	for(int tau=0; tau<nGraphs; tau++)
	{
		for(int k=0; k<nMarkers[tau]-1; k++)
		{
			ofs<<rho[tau][k];
			if(tau==nGraphs-1 && k==nMarkers[tau]-2) {}
			else ofs<<"\t";
		}
	}
	ofs<<endl;
}

void Chain::printRhoBackg(ofstream& ofs, int iter)
{
	ofs<<iter<<"\t";
	for(int tau=0; tau<nGraphs; tau++)
	{
		for(int k=0; k<nMarkers[tau]-1; k++)
		{
			ofs<<rhoBackg[tau][k];
			if(tau==nGraphs-1 && k==nMarkers[tau]-2) {}
			else ofs<<"\t";
		}
	}
	ofs<<endl;
}

void Chain::printMarkerTMRCAs(ofstream& ofs, int iter)
{
	int totnmarkers = 0;
	for(int tau=0; tau<nGraphs; tau++) totnmarkers += nMarkers[tau];

	double* tmrcas = new double[totnmarkers];
	markerTMRCAs(tmrcas);

	ofs<<iter;
	for(int i=0; i<totnmarkers; i++) ofs<<"\t"<<tmrcas[i];
	ofs<<endl;

	delete [] tmrcas;
}

void Chain::printPars(ofstream& ofs, int iter)
{
	ofs<<iter;
	ofs<<"\t"<<theta<<"\t"<<rhoBackgLambda;
	ofs<<endl;
}

void Chain::postHaplotypes(chrHaps** postHap, ofstream& ofsHap)
{
	MapHap**** Hapdist;
	Hapdist = new MapHap***[nGraphs];

	for(int l=0; l<nGraphs; l++)
	{
		ofsHap<<"Graph # "<<l<<endl<<endl;
		Hapdist[l] = new MapHap**[nSeq[l]];

		for(int tipth=0; tipth<nSeq[l]; tipth++)
		{
			ofsHap<<"Indiv "<<tipth<<endl;

			int nbins = (int)postHap[l][tipth].haps.size();
			Hapdist[l][tipth] = new MapHap*[nbins];

			double sum=0;
			for(int j=0; j<nbins; j++) sum += postHap[l][tipth].haps[j]->count;
			for(int j=0; j<nbins; j++)
			{
				Hapdist[l][tipth][j] = new MapHap;

				Hapdist[l][tipth][j]->key = postHap[l][tipth].haps[j]->haplotype;
				Hapdist[l][tipth][j]->frequency = postHap[l][tipth].haps[j]->count/sum;
			}

			qsort(Hapdist[l][tipth], nbins, sizeof(MapHap*), Util::compQsortFreq);

			double sumfreq =0;
			for(int j=0; j<nbins; j++)
			{
				sumfreq += Hapdist[l][tipth][j]->frequency;
				if(sumfreq<=0.95) Hapdist[l][tipth][j]->sig =1;
				else Hapdist[l][tipth][j]->sig =0;
			}

			for(int j=0; j<nbins; j++)
			{
				int* ahap = Hapdist[l][tipth][j]->key;
				for(int k=0; k<nMarkers[l]; k++) ofsHap<<(char)ahap[k]<<" "; ofsHap<<":\t";
				ofsHap<<Hapdist[l][tipth][j]->frequency<<"\t"<<Hapdist[l][tipth][j]->sig<<endl;
			}
			ofsHap<<endl;
		}//loop over all tips
	}//loop over all graphs
}

void Chain::postMissingBases(ofstream& ofsMs)
{
	vector<missSnp>::iterator vi;
	int tot;
	for(vi=missing->begin(); vi!=missing->end(); vi++)
	{
		ofsMs<<(*vi).graph<<"\t"<<(*vi).chrid<<"\t"<<(*vi).locus;
		tot = 0; for(int i=0; i<4; i++) tot+=(*vi).freq[i];
		for(int i=0; i<4; i++) ofsMs<<"\t"<<(*vi).freq[i]/(double)tot;
		ofsMs<<endl;
	}
}

void Chain::postRootHaplotype(rootHaps* postRoot, ofstream& ofsRoot)
{
	MapHap*** Hapdist;
	Hapdist = new MapHap**[nGraphs];

	for(int l=0; l<nGraphs; l++)
	{
		ofsRoot<<"Graph # "<<l<<endl<<endl;

		int nbins = (int)postRoot[l].haps.size();
		Hapdist[l] = new MapHap*[nbins];

		double sum=0;
		for(int j=0; j<nbins; j++) sum += postRoot[l].haps[j]->count;
		for(int j=0; j<nbins; j++)
		{
			Hapdist[l][j] = new MapHap;

			Hapdist[l][j]->key = postRoot[l].haps[j]->haplotype;
			Hapdist[l][j]->frequency = postRoot[l].haps[j]->count/sum;
		}

		qsort(Hapdist[l], nbins, sizeof(MapHap*), Util::compQsortFreq);

		double sumfreq =0;
		for(int j=0; j<nbins; j++)
		{
			sumfreq += Hapdist[l][j]->frequency;
			if(sumfreq<=0.95) Hapdist[l][j]->sig =1;
			else Hapdist[l][j]->sig =0;
		}

		for(int j=0; j<nbins; j++)
		{
			int* ahap = Hapdist[l][j]->key;
			for(int k=0; k<nMarkers[l]; k++) ofsRoot<<(char)ahap[k]<<" "; ofsRoot<<":\t";
			ofsRoot<<Hapdist[l][j]->frequency<<"\t"<<Hapdist[l][j]->sig<<endl;
		}
		ofsRoot<<endl;
	}//loop over all graphs
}

void Chain::readMcmcFile(ifstream& ifs)
{
	//readin genealogies
	int id; int ids[4]; double coaltime, rectime, bkpoint;
	int follow;

	vector<Node*>::iterator it;
	for(int tau=0; tau<nGraphs; tau++)
	{
		vector<Node*> nodesvector;
		int num_nodes;
		ifs>>num_nodes;

		double pretime=0;
		for(int i=0; i<num_nodes; i++)
		{
			ifs>>id; ifs>>coaltime; ifs>>rectime;

			//prevent identical time
			if(coaltime==0 && rectime!=0 && rectime==pretime) {rectime += EPSILON;}
			if(rectime==0 && coaltime!=0 && coaltime==pretime) {coaltime += EPSILON;}
			if(coaltime==0) pretime=rectime;
			else pretime=coaltime;

			for(int j=0; j<4; j++) {ifs>>ids[j];}
			ifs>>bkpoint; ifs>>follow;

			//start generating node
			Node* anode = new Node(id, coaltime, rectime, nMarkers[tau]);
			for(int j=0; j<4; j++) anode->ids[j] = ids[j];
			anode->setBkpoint(bkpoint);
			anode->setFollow(follow);
			nodesvector.push_back(anode);

			int nmarkers = nMarkers[tau];
			ALLELE* leftancloc = new ALLELE[nmarkers];
			int all999=1;
			for(int i=0; i<nmarkers; i++)
			{
				ifs>>leftancloc[i];
				if(leftancloc[i]!=999) all999=0;
			}
			if(all999) { delete [] leftancloc;}
			else anode->setLeftAncLocs(leftancloc);

			ALLELE* rightancloc = new ALLELE[nmarkers];
			all999=1;
			for(int i=0; i<nmarkers; i++)
			{
				ifs>>rightancloc[i];
				if(rightancloc[i]!=999) all999=0;
			}
			if(all999) { delete [] rightancloc;}
			else anode->setRightAncLocs(rightancloc);
		}//finish generating all of the nodes

		genealogy->at(tau)->resetGraph(nodesvector);

		//clear memory
		for(it=nodesvector.begin(); it!=nodesvector.end(); it++) delete (*it); nodesvector.clear();
	}//finish reading graphs

	//read in parameters (rhoBGLambda) and variables (rhoBG and hostpots)
	ifs>>rhoBackgLambda;

	for(int tau=0; tau<nGraphs; tau++)
	{
		for(int i=0; i<nMarkers[tau]-1; i++) ifs>>rhoBackg[tau][i];
	}

	clearHotspots(hotspots);
	int nhs; ifs>>nhs;
	for(int i=0; i<nhs; i++)
	{
		Hotspot* hs = new Hotspot;
		ifs>>hs->X1; ifs>>hs->X2; ifs>>hs->Z;
		hotspots->push_back(hs);
	}

	for(int tau=0; tau<nGraphs; tau++)
		updateRho(rho[tau], rhoBackg[tau], hotspots, phyDis[tau], nMarkers[tau]);

	//read in theta
	ifs>>theta;

	//print
	cout<<"rho: "<<endl;
	printRho();

	cout<<"hotspots: "<<endl;
	printHotspots();

	//update logllh and logprior
	double ll, lp;
	for(int tau=0; tau<nGraphs; tau++)
	{
		ll = genealogy->at(tau)->calculateLogllh(theta, -1, statFreq);
		genealogy->at(tau)->setLogllh(ll);

		lp = genealogy->at(tau)->calculateLogprior(rho[tau], phyDis[tau]);
		genealogy->at(tau)->setLogprior(lp);
	}
}

void Chain::writeMcmcFile(ofstream& ofs)
{
	printGenealogy(ofs);

	ofs<<rhoBackgLambda<<endl;

	for(int tau=0; tau<nGraphs; tau++)
	{
		for(int i=0; i<nMarkers[tau]-1; i++) ofs<<rhoBackg[tau][i]<<"\t";
	}
	ofs<<endl;

	ofs<<hotspots->size()<<endl;
	vector<Hotspot*>::iterator it;
	for(it=hotspots->begin(); it!=hotspots->end(); it++)
		ofs<<(*it)->X1<<"\t"<<(*it)->X2<<"\t"<<(*it)->Z<<endl;
	ofs<<endl;

	ofs<<theta<<endl;
}

void HChain::swapChains(Chain** chains, int nchains, gsl_rng* gslr)
{
	if(nchains==1 || gsl_rng_uniform_pos(gslr)<0.5) return;

	int k = gsl_rng_uniform_int(gslr, nchains-1);
	int j = k+1;
	Chain* chk = chains[k];
	Chain* chj = chains[j];

	double logpriorChk = 0;
	double logpriorChj = 0;

	logpriorChk += chk->logPriorRhoBackg(chk->getRhoBackg(), chk->getRhoBackgLambda());
	logpriorChj += chj->logPriorRhoBackg(chj->getRhoBackg(), chj->getRhoBackgLambda());

	logpriorChk += chk->logPriorHotspots(chk->getHotspots());
	logpriorChj += chj->logPriorHotspots(chj->getHotspots());

	logpriorChk += chk->logPriorTheta(chk->getTheta());
	logpriorChj += chj->logPriorTheta(chj->getTheta());

	logpriorChk += chk->logPriorGenealogy();
	logpriorChj += chj->logPriorGenealogy();

	double logpriorRatio = (logpriorChk-logpriorChj) + (logpriorChj-logpriorChk);

	double logllhChk = chk->logllhGenealogy();
	double logllhChj = chj->logllhGenealogy();

	double logllhRatio = chj->getBeta()*(logllhChk-logllhChj) + chk->getBeta()*(logllhChj-logllhChk);

	double alpha = exp(logpriorRatio + logllhRatio);

	if(gsl_rng_uniform_pos(gslr)<alpha)
	{
		Chain* cbk = chains[k];
		chains[k] = chains[j];
		chains[j] = cbk;

		//keep beta, numProp, and numAcc unswapped, because they should be bounded to the chain
		double bbk = chains[k]->getBeta();
		chains[k]->setBeta(chains[j]->getBeta());
		chains[j]->setBeta(bbk);

		int* ibk = chains[k]->getNumProp();
		chains[k]->setNumProp(chains[j]->getNumProp());
		chains[j]->setNumProp(ibk);

		ibk = chains[k]->getNumAcc();
		chains[k]->setNumAcc(chains[j]->getNumAcc());
		chains[j]->setNumAcc(ibk);

		chains[k]->setNumAccI(SWAP, chains[k]->getNumAccI(SWAP)+1);
		chains[j]->setNumAccI(SWAP, chains[j]->getNumAccI(SWAP)+1);
	}
	chains[k]->setNumPropI(SWAP, chains[k]->getNumPropI(SWAP)+1);
	chains[j]->setNumPropI(SWAP, chains[j]->getNumPropI(SWAP)+1);
}

void HChain::monitor(Chain** chains, int nchains, int num, ofstream& ofs)
{
	ofs<<num<<"\t";
	for(int i=0; i<nchains; i++)
	{
		double lll = chains[i]->logllhGenealogy();
		double lprior = chains[i]->logPriorGenealogy();
		lprior += chains[i]->logPriorRhoBackg(chains[i]->getRhoBackg(), chains[i]->getRhoBackgLambda());
		lprior += chains[i]->logPriorHotspots(chains[i]->getHotspots());
		ofs<<lprior<<"\t"<<lll<<"\t"<<lprior+lll<<"\t"<<chains[i]->getHotspots()->size()<<"\t";
	}
	ofs<<endl;
}

