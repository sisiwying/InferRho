/*
	Copyright, Ying Wang, yingw09@gmail.com
*/

#include "graph.h"

#define MAXNHS 10000
#define MAXLAMBDA 5000

#define GEN 0
#define TREE 1
#define MISS 2
#define HAP 3
#define ANC 4
#define HOTSPC 5
#define HOTSPCG 6
#define HOTSPA 7
#define HOTSPD 8
#define RHOBGR 9
#define RHOBGL 10
#define THE 11
#define SWAP 12
#define NC 13


typedef struct {
	double X1; //start position of the hotspot
	double X2; //end position of the hotspot
	double Z; //strength of the hotspot
}Hotspot;


typedef struct{
	int graph;
	int chrid;
	int locus;
	int* freq;
}missSnp;


typedef struct{
	int* haplotype;
	int count;
}haplotypeCount;


typedef struct{
	vector<haplotypeCount*> haps;
	int chrid;
}chrHaps;


typedef struct{
	vector<haplotypeCount*> haps;
	int graphid;
}rootHaps;


class Chain
{
private:
	double beta; //relate to the temperature of the chain
	int nGraphs;
	int* nSeq; //pointers point to the input data
	int* nMarkers;
	int** phyDis;
	int*** seqMatrix;
	int startInterv;
	int endInterv;
	double* statFreq;
	vector<missSnp>* missing;
	int*** SNPs;

	vector<Graph*>* genealogy; //genealogy consists of an array of graphs (ARGs)

	//the following are the variables and parameters in the recombination rate model
	double** rho; //matrix of rho for ngraphs*(nmarkers-1)
	double** rhoBackg;
	int rhoBackgLambda; //rhoBackg ~ exp(lambda); lambda ~ Uniform[1, LAMBDAMAX]
	vector<Hotspot*>* hotspots;
	double theta; //theta is constant across the interval

	//fixed parameters
	double lambdaHalfWidth;
	double lambdaSimZ;
	double hotspMuZ;
	double hotspSigmaZ;
	double hotspLambdaX1;
	double hotspLambdaX2;
	double thetaShape;
	double thetaScale;

	//mixing parameters in the MCMC
	double deltaNode;
	double dHap;
	double dAnc;
	double deltaHotsp;
	double deltaHotspGlobal;
	double deltaRhoBackg;
	int deltaRhoBackgLambda;
	double deltaTheta;
	//prob of proposing each change
	double prGen, prTree, prMiss, prHap, prAnc, prRhoBackg, prHotsp, prTheta;

	int* numProp;
	int* numAcc;

	gsl_rng* gslr;

public:
	Chain(double, int, int*, int*, int**, int***, int, int, double*, vector<missSnp>*, int***);
	~Chain();

	vector<Graph*>* getGenealogy() {return genealogy;}
	double** getRho() {return rho;}
	double** getRhoBackg() {return rhoBackg;}
	vector<Hotspot*>* getHotspots() {return hotspots;}
	double getTheta() {return theta;}
	int getRhoBackgLambda() {return rhoBackgLambda;}
	double getBeta() {return beta;}
	void setBeta(double b) {beta=b;}
	int* getNumProp() {return numProp;}
	int* getNumAcc() {return numAcc;}
	int getNumPropI(int i) {return numProp[i];}
	int getNumAccI(int i) {return numAcc[i];}
	void setNumProp(int* np) {numProp=np;}
	void setNumAcc(int* nc) {numAcc=nc;}
	void setNumPropI(int i, int x) {numProp[i]=x;}
	void setNumAccI(int i, int x) {numAcc[i]=x;}

	void setupMixingPar(double, double, double, double, double, double, int, double);
	void adjMixingParameters();
	double adjDeltaTemp(double);
	void printMixingParameters(ofstream&);
	void printBeta(ofstream&);
	void copyChain(Chain&, Chain&);
	void simulateGenealogy();
	void initializeChain();
	void updateRho(double*, double*, vector<Hotspot*>*, int*, int);
	void printRho();
	void readMcmcFile(ifstream&);
	void writeMcmcFile(ofstream&);

	void modifyGenealogy();
	void modifyTree();
	void modifyMissingData();
	void modifyHaplotype();
	void modifyAncestralStates();
	void modifyRhoBackg();
	void modifyHotspot();
	void modifyTheta();

	void modifyChain(int);

	void changeRhoBackgLambda();
	void changeRhoBackgRate();
	void changeHotspAreaConst();
	void changeHotspot(double);
	void changeHotspotGlobal(double);
	void insertHotspot(double);
	void deleteHotspot(double);
	void getProposalProb(double*);

	void swapChains(Chain*);

	void copyHotspots(vector<Hotspot*>*, vector<Hotspot*>*);
	void clearHotspots(vector<Hotspot*>*);
	void printHotspots();
	void printHotspots(ofstream&, int);
	void printHotspots(vector<Hotspot*>*);
	double logPriorHotspots(vector<Hotspot*>*);
	void clearGenealogy(vector<Graph*>*);
	void copyGenealogy(vector<Graph*>*, vector<Graph*>*);
	double logPriorGenealogy();
	void copyRate(double**, double**);
	double logllhGenealogy();
	void recomGenealogy(vector<double>*);
	void treeLengths(double**);
	double proposeHotspots(vector<Hotspot*>*, vector<Hotspot*>*);

	void setupProb(double, double, double, double, double, double, double, double);
	void outputAccProb(ofstream&);
	double grandTMRCA();
	double logPriorRhoBackg(double**, double);
	void markerTMRCAs(double*);
	double logPriorTheta(double);

	void printMarkerTMRCAs(ofstream&, int);
	void printPars(ofstream&, int);
	void printGenealogy();
	void printGenealogy(ofstream&);
	void sampleHaplotypes(chrHaps**);
	void sampleMissingBases();
	void sampleRoot(rootHaps*);
	bool hapsAreSame(int*, int*, int);
	void printRec(ofstream&, int);
	void printRho(ofstream&, int);
	void printRhoBackg(ofstream&, int);
	void postHaplotypes(chrHaps**, ofstream&);
	void postMissingBases(ofstream&);
	void postRootHaplotype(rootHaps*, ofstream&);
	void monitor(Chain**, int, int, ofstream&);
};

class HChain
{
public:
	static void swapChains(Chain**, int, gsl_rng*);
	static void monitor(Chain**, int, int, ofstream&);
};

