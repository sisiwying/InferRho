/*
	Copyright, Ying Wang, yingw09@gmail.com
*/

#include <omp.h>
#include <stdio.h>
#include <stdlib.h>

#include "chain.h"

#define SWINT 100
#define THIN 30

